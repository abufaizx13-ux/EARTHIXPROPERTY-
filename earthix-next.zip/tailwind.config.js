/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx}", "./components/**/*.{js,jsx}", "./lib/**/*.{js,jsx}"],
  // The site's look is defined once in app/globals.css (the original teal SaaS design). Tailwind's own reset
  // is disabled so it cannot alter that design; Tailwind utilities remain available for new markup.
  corePlugins: { preflight: false, container: false },
  theme: {
    extend: {
      colors: {
        teal: { DEFAULT: "#3d90a6", dark: "#167a94", soft: "#e6f4f6", border: "#b9d9e0" },
        mint: { DEFAULT: "#effcfb", strong: "#c9f5ee" },
        ink: "#0f172a",
        gold: "#d9a441",
      },
      fontFamily: {
        display: ["var(--f-caveat)", "Caveat Brush", "cursive"],
        sans: ["var(--f-inter)", "Inter", "system-ui", "sans-serif"],
      },
      borderRadius: { card: "20px", big: "24px", btn: "10px", tile: "12px" },
    },
  },
  plugins: [],
};
