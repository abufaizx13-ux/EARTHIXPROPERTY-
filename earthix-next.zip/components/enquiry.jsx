"use client";

import React, { useState, useEffect, useLayoutEffect, useRef, useCallback, useMemo, useContext, createContext, startTransition, useId } from "react";
import { L } from "@/lib/nav";
import { pick, tr } from "@/lib/i18n";
import { useLang } from "@/lib/lang";
import { EMAIL_RE, MOBILE_RE, cleanMobile, fmtINR, makeId } from "@/lib/helpers";
import { Err, Field, Icon, WhatsAppIcon, useFocusTrap } from "@/components/common";
import { acctEmail, getDb, saveDb } from "@/lib/store";
import { QUEUED_MSG, REMOTE, submitRemote } from "@/lib/backend";
import { waLink } from "@/lib/config";
import { waText } from "@/lib/content";
import { priceSuffix } from "@/lib/seed";
import { ex, hint } from "@/lib/forms";


export function EnquiryModalInner({ settings, toast }) {
  const { lang, t } = useLang();
  const ref = useRef(null);
  const [open, setOpen] = useState(false);
  const [p, setP] = useState(null);
  const blank = () => ({ name: "", mobile: "", email: "", message: "", consent: false });
  const [f, setF] = useState(blank);
  const [err, setErr] = useState({});
  const [done, setDone] = useState(null);
  const [busy, setBusy] = useState(false);
  const close = useCallback(() => { ["pm-escrim", "pm-enquiry"].forEach((id) => { const el = document.getElementById(id); if (el) el.classList.remove("shown"); }); setOpen(false); }, []);
  useFocusTrap(open, ref, close);
  useEffect(() => {
    const on = (e) => { setP(e.detail || null); setF(blank()); setErr({}); setDone(null); setOpen(true); };
    window.addEventListener("pm-enquiry", on);
    return () => window.removeEventListener("pm-enquiry", on);
  }, []);
  const up = (k) => (e) => setF((s) => ({ ...s, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value }));
  const submit = (e) => {
    e.preventDefault();
    const er = {};
    if (f.name.trim().length < 2) er.name = "Enter your name.";
    if (!MOBILE_RE.test(f.mobile)) er.mobile = "Enter a valid 10-digit mobile number.";
    if (f.email && !EMAIL_RE.test(f.email)) er.email = "Enter a valid email.";
    if (f.message.length > 1000) er.message = "That is too long. Please shorten it.";
    if (!f.consent) er.consent = "Please accept to continue.";
    const db = getDb(); const now = Date.now();
    const recent = (db.erate || []).filter((x) => now - x < 600000);
    if (!Object.keys(er).length && recent.length >= 5) er.form = "Too many requests. Try again in 10 minutes.";
    setErr(er);
    if (Object.keys(er).length) { return; }
    const q = { id: makeId("ENQ"), acct: acctEmail(), propertyId: p ? p.id : "", propertyTitle: p ? pick(p.title, "en") : "", name: f.name.trim(), mobile: f.mobile, email: f.email.trim(), message: f.message.trim(), status: 0, at: now };
    const finish = () => { db.enquiries = (db.enquiries || []).concat(q); db.erate = recent.concat(now); if (!saveDb(db).ok) { toast(t("storageFull")); return; } setDone(q); };
    if (!REMOTE) { finish(); return; }
    setBusy(true);
    submitRemote("send_enquiry", { p_id: q.id, p_property_id: q.propertyId, p_property_title: q.propertyTitle, p_name: q.name, p_mobile: q.mobile, p_email: q.email, p_message: q.message }).then((res) => {
      setBusy(false);
      if (!res.ok) { setErr({ form: res.error }); return; }
      finish(); if (res.queued) toast(QUEUED_MSG);
    });
  };
  const ptitle = p ? pick(p.title, lang) : "";
  return (
    <div>
      <div id="pm-escrim" className={"scrim fade" + (open ? " shown" : "")} onPointerDown={close} aria-hidden="true" />
      <div id="pm-enquiry" className={"modal" + (open ? " shown" : "")} aria-hidden={!open} ref={ref} role="dialog" aria-modal="true" aria-label={tr("Send Request")}>
        <button type="button" className="burger" style={{ position: "absolute", top: 4, insetInlineEnd: 4 }} aria-label={t("close")} onClick={close}><Icon name="close" size={22} /></button>
        {done ? (
          <div>
            <h2 className="ct" style={{ marginTop: 8 }}>{tr("Request sent")}</h2>
            <p className="cb"><b>{tr("ID:")}</b> <span dir="ltr">{done.id}</span>{ptitle ? <><br /><b>{tr("Property")}:</b> {ptitle}</> : null}<br />{tr("Our team has received your request and will call you soon.")}</p>
            <div className="stack">
              <a className="btn btn-wa" href={L(waLink(settings.whatsapp, waText("general", {}, lang)))} target="_blank" rel="noopener noreferrer"><WhatsAppIcon size={18} />{tr("WhatsApp")}</a>
              <button type="button" className="btn btn-primary" onClick={close}>{t("close")}</button>
            </div>
          </div>
        ) : (
          <form onSubmit={submit} noValidate>
            <h2 className="ct" style={{ marginTop: 8 }}>{tr("Send Request")}</h2>
            {ptitle && <p className="cb" style={{ marginTop: 0 }}><b>{ptitle}</b>{p && p.price ? " · " + fmtINR(p.price) + (priceSuffix(p) ? t("perMonth") : "") : ""}</p>}
            <Err m={err.form} />
            <Field id="en-name" label={tr("Your name")} error={err.name}><input id="en-name" placeholder={ex("name")} className="inp" autoComplete="name" value={f.name} onChange={up("name")} /></Field>
            <Field id="en-mobile" hint={hint("mobile")} label={tr("Mobile number")} error={err.mobile}><input id="en-mobile" placeholder={ex("mobile")} className="inp" dir="ltr" inputMode="numeric" autoComplete="tel" value={f.mobile} onChange={(e) => setF((s) => ({ ...s, mobile: cleanMobile(e.target.value) }))} /></Field>
            <Field id="en-email" label={tr("Email (optional)")} error={err.email}><input id="en-email" placeholder={ex("email")} className="inp" dir="ltr" type="email" value={f.email} onChange={up("email")} /></Field>
            <Field id="en-msg" label={tr("Message (optional)")} error={err.message}><textarea id="en-msg" className="inp" style={{ height: 88, padding: 12 }} maxLength={1000} value={f.message} onChange={up("message")} /></Field>
            <label className="chk"><input id="en-consent" type="checkbox" checked={f.consent} onChange={up("consent")} /> {tr("I agree to be contacted about this request.")}</label>
            <Err m={err.consent} />
            <button type="submit" disabled={busy} className="btn btn-primary" style={{ width: "100%", marginTop: 14 }}>{busy ? "…" : tr("Send Request") + " ›"}</button>
          </form>
        )}
      </div>
    </div>
  );
}

export const EnquiryModal = React.memo(EnquiryModalInner);
