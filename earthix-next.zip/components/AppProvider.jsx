"use client";

import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { BRAND, BRAND_TAG, IMG, applyBrand } from "@/lib/brand";
import { LANG_NOW, T, makeT, tr } from "@/lib/i18n";
import { LangCtx } from "@/lib/lang";
import { LANG_IDX } from "@/lib/brand";
import { getDb, hydratePublic, loadLocal, saveDb } from "@/lib/store";
import { REMOTE, flushOutbox, getSbSession, sbLogout, syncPublic } from "@/lib/backend";
import { installLinkHandler, navigate, setRouter } from "@/lib/nav";
import { loadFonts, openMeeting } from "@/lib/dom";
import { ErrorBoundary, CookieBanner, OfflineBanner, useCardFx } from "@/components/common";
import { Footer, Floating, Navbar } from "@/components/chrome";
import { MeetingModal } from "@/components/meeting";
import { EnquiryModal } from "@/components/enquiry";
import { InfoHost } from "@/components/info";
import { MediaViewerHost } from "@/components/property";
import { PickerHost } from "@/components/forms";

const AppCtx = createContext(null);
export const useApp = () => useContext(AppCtx);

// Wraps every page: language, the shared in-memory db, toast, saved properties, and the site chrome
// (navbar, footer, modals). `pub` is the public content fetched on the server (settings, properties, reviews).
export default function AppProvider({ lang, pub, children }) {
  // Set before any child renders, on the server and in the browser, so tr()/t() use the right language.
  LANG_NOW.v = lang;
  const hydrated = useRef(null);
  if (hydrated.current !== pub) { hydratePublic(pub); hydrated.current = pub; }

  const router = useRouter();
  setRouter(router);
  const [db, setDbState] = useState(() => getDb());
  const [msg, setMsg] = useState("");
  // Date-dependent popups are mounted only in the browser, so server HTML never bakes in a stale date.
  const [mounted, setMounted] = useState(false);
  useEffect(() => { setMounted(true); }, []);
  const mainRef = useRef(null);
  useCardFx();

  const refresh = useCallback(() => setDbState({ ...getDb() }), []);
  const setDb = useCallback((d) => setDbState(d), []);

  const settings = (db && db.settings) || getDb().settings;
  applyBrand(settings);
  const brandKey = BRAND.join("|") + "|" + BRAND_TAG.join("|") + "|" + (IMG.logo ? IMG.logo.length : 0);
  const t = useMemo(() => makeT(lang), [lang, brandKey]);

  const setLang = useCallback((l) => {
    if (l === lang) return;
    const rest = window.location.pathname.replace(/^\/(en|hi|ur)(?=\/|$)/, "");
    navigate("/" + l + rest + window.location.search);
  }, [lang]);
  const ctx = useMemo(() => ({ lang, setLang, t }), [lang, setLang, t]);

  const toast = useCallback((m) => { setMsg(m); setTimeout(() => setMsg(""), 2600); }, []);
  const toggle = useCallback((id) => {
    const cur = getDb(); const s = cur.saved || [];
    cur.saved = s.includes(id) ? s.filter((x) => x !== id) : s.concat(id);
    const r = saveDb(cur); setDbState({ ...cur });
    toast(r.ok ? T.savedOk[LANG_IDX[LANG_NOW.v] ?? 0] : T.storageFull[LANG_IDX[LANG_NOW.v] ?? 0]);
  }, [toast]);
  const onBook = useCallback((p) => openMeeting(typeof p === "string" ? p : "buy"), []);
  const logout = useCallback(() => {
    sbLogout(); const d = getDb(); d.session = null; saveDb(d); setDbState({ ...d }); toast("Logged out"); navigate("#/");
  }, [toast]);

  // After the first paint: bring in this browser's saved data and keep the site content fresh.
  useEffect(() => {
    const d = loadLocal();
    // a stored login is only trusted for 7 days and only while the server session still exists
    if (d.session && (Date.now() - (d.session.at || 0) > 604800000 || (REMOTE && !getSbSession()))) { d.session = null; saveDb(d); }
    setDbState({ ...d });
    const off = installLinkHandler(openMeeting);
    const onDb = () => setDbState({ ...getDb() });
    window.addEventListener("pm-db", onDb);
    let dead = false;
    const run = () => {
      if (!REMOTE) return;
      flushOutbox();
      syncPublic().then((nd) => { if (nd && !dead) { saveDb(nd); setDbState({ ...nd }); } }).catch(() => {});
    };
    const ric = window.requestIdleCallback;
    const id = ric ? ric(run, { timeout: 2000 }) : setTimeout(run, 400);
    window.addEventListener("online", run);
    return () => {
      dead = true; off();
      window.removeEventListener("pm-db", onDb); window.removeEventListener("online", run);
      if (ric) { if (window.cancelIdleCallback) window.cancelIdleCallback(id); } else clearTimeout(id);
    };
  }, []);

  useEffect(() => { loadFonts(lang); }, [lang]);

  const saved = useMemo(() => (db && db.saved) || [], [db]);
  const value = useMemo(() => ({ lang, db, setDb, refresh, settings, saved, toggle, onBook, toast, logout }), [lang, db, setDb, refresh, settings, saved, toggle, onBook, toast, logout]);

  return (
    <ErrorBoundary>
      <LangCtx.Provider value={ctx}>
        <AppCtx.Provider value={value}>
          <PickerHost />
          <InfoHost settings={settings} />
          <button type="button" className="skip" onClick={() => mainRef.current && mainRef.current.focus()}>{t("skip")}</button>
          <OfflineBanner />
          <Navbar settings={settings} user={db.session} onLogout={logout} onBook={onBook} savedCount={saved.length} />
          <main id="main" ref={mainRef} tabIndex={-1} style={{ outline: "none" }}>{children}</main>
          <Footer settings={settings} />
          {mounted && <MeetingModal settings={settings} toast={toast} />}
          {mounted && <EnquiryModal settings={settings} toast={toast} />}
          <MediaViewerHost />
          <Floating settings={settings} />
          <CookieBanner />
          {msg && <div className="toast" role="status">{tr(msg)}</div>}
        </AppCtx.Provider>
      </LangCtx.Provider>
    </ErrorBoundary>
  );
}
