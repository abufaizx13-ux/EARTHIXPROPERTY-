"use client";

import React, { useState, useEffect, useLayoutEffect, useRef, useCallback, useMemo, useContext, createContext, startTransition, useId } from "react";
import { LANG_IDX } from "@/lib/brand";
import { pick, tr } from "@/lib/i18n";
import { useLang } from "@/lib/lang";
import { rvAgo, rvColor, rvRating, rvVoted } from "@/lib/content";
import { SEED_REVIEWS, rvInitial } from "@/lib/seed";
import { Heading, Icon, PageHead, Section, SectionHead, Stars } from "@/components/common";
import { allReviews, getDb, saveDb } from "@/lib/store";
import { EMAIL_RE, makeId } from "@/lib/helpers";
import { PickBtn } from "@/components/forms";
import { QUEUED_MSG, REMOTE, submitRemote } from "@/lib/backend";
import { catName } from "@/lib/config";


export function ReviewItem({ r, lang, voted, onHelpful }) {
  const [more, setMore] = useState(false);
  const L = (en, hi, ur) => [en, hi, ur][LANG_IDX[lang] ?? 0];
  const txt = pick(r.text, lang) || "";
  const role = pick(r.role, lang) || "";
  const reply = r.reply ? pick(r.reply, lang) : "";
  const long = txt.length > 170;
  return (
    <article className="rv-item">
      <div className="rv-top">
        <span className="rv-av" style={{ background: rvColor(r.name) }} aria-hidden="true">{rvInitial(r.name)}</span>
        <div className="rv-who"><b>{r.name}</b>{role ? <small>{role}</small> : null}</div>
      </div>
      <div className="rv-meta"><Stars value={rvRating(r)} size={15} />{r.at ? <span className="rv-ago">{rvAgo(r.at, lang)}</span> : null}</div>
      <p className={"rv-text" + (more ? " open" : "")}>{txt}</p>
      {long && <button type="button" className="rv-more" onClick={() => setMore((v) => !v)}>{more ? L("Less", "कम दिखाएँ", "کم دکھائیں") : L("More", "और पढ़ें", "مزید پڑھیں")}</button>}
      {reply ? <div className="rv-reply"><b>{L("Response from the owner", "मालिक का जवाब", "مالک کا جواب")}</b><p>{reply}</p></div> : null}
      <div className="rv-act">
        <button type="button" className={"rv-help" + (voted ? " on" : "")} aria-pressed={voted} onClick={() => onHelpful(r.id)}>
          <svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z" /></svg>
          {L("Helpful", "उपयोगी", "مفید")}{r.helpful ? " · " + r.helpful : ""}
        </button>
      </div>
    </article>
  );
}

export function ReviewForm({ onClose, onDone }) {
  const { lang } = useLang();
  const L = (en, hi, ur) => [en, hi, ur][LANG_IDX[lang] ?? 0];
  const [name, setName] = useState(""), [place, setPlace] = useState(""), [text, setText] = useState("");
  const [rate, setRate] = useState(0), [hov, setHov] = useState(0), [err, setErr] = useState("");
  useEffect(() => {
    const k = (e) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", k);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.removeEventListener("keydown", k); document.body.style.overflow = prev; };
  }, [onClose]);
  const submit = (e) => {
    e.preventDefault();
    if (name.trim().length < 2) { setErr(L("Enter your name.", "अपना नाम डालें।", "اپنا نام درج کریں۔")); return; }
    if (!rate) { setErr(L("Tap the stars to give a rating.", "रेटिंग देने के लिए सितारों पर टैप करें।", "ریٹنگ دینے کے لیے ستاروں پر ٹیپ کریں۔")); return; }
    if (text.trim().length < 10) { setErr(L("Write at least 10 characters.", "कम से कम 10 अक्षर लिखें।", "کم از کم 10 حروف لکھیں۔")); return; }
    let last = 0; try { last = Number(window.localStorage.getItem("pm_rv_last") || 0); } catch (x) { last = 0; }
    if (Date.now() - last < 60000) { setErr(L("Please wait a minute before posting another review.", "दूसरी समीक्षा डालने से पहले कृपया एक मिनट रुकें।", "دوسرا جائزہ ڈالنے سے پہلے براہِ کرم ایک منٹ رکیں۔")); return; }
    const rv = { id: makeId("RV"), name: name.trim(), role: [place.trim()], text: [text.trim()], rating: rate, at: Date.now(), helpful: 0, visible: false, pending: true };
    try { window.localStorage.setItem("pm_rv_last", String(Date.now())); } catch (x) { /* memory only */ }
    if (REMOTE) {
      // Goes to the admin panel (Admin > Reviews) as "pending"; it is shown on the site only after approval.
      submitRemote("submit_review", { p_data: rv }).then((res) => { if (!res.ok) { setErr(res.error); return; } onDone(); });
      return;
    }
    const d = getDb();
    d.reviews = (d.reviews || SEED_REVIEWS.map((x) => ({ ...x }))).concat(rv);
    saveDb(d);
    window.dispatchEvent(new Event("pm-db"));
    onDone();
  };
  const shown = hov || rate;
  return (
    <div>
      <div className="rv-bg" onPointerDown={onClose} aria-hidden="true" />
      <form className="rv-modal" role="dialog" aria-modal="true" aria-label={L("Write a review", "समीक्षा लिखें", "جائزہ لکھیں")} onSubmit={submit} noValidate>
        <div className="rv-mh"><b>{L("Write a review", "समीक्षा लिखें", "جائزہ لکھیں")}</b><button type="button" className="burger" style={{ width: 40, height: 40 }} aria-label={L("Close", "बंद करें", "بند کریں")} onClick={onClose}><Icon name="close" size={20} /></button></div>
        <div className="rv-pick" role="radiogroup" aria-label={L("Your rating", "आपकी रेटिंग", "آپ کی ریٹنگ")} onMouseLeave={() => setHov(0)}>
          {[1, 2, 3, 4, 5].map((n) => <button key={n} type="button" role="radio" aria-checked={rate === n} aria-label={n + " / 5"} className={shown >= n ? "on" : ""} onMouseEnter={() => setHov(n)} onClick={() => setRate(n)}>★</button>)}
        </div>
        <label className="lbl" htmlFor="rv-name">{L("Your name", "आपका नाम", "آپ کا نام")}</label>
        <input id="rv-name" className="inp" maxLength={60} value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" />
        <label className="lbl" htmlFor="rv-place" style={{ marginTop: 12 }}>{L("Work and place (optional)", "काम और जगह (वैकल्पिक)", "کام اور جگہ (اختیاری)")}</label>
        <input id="rv-place" className="inp" maxLength={60} placeholder={L("e.g. Farmer, Salkhua", "जैसे: किसान, सालखुआ", "مثلاً: کسان، سالتھوا")} value={place} onChange={(e) => setPlace(e.target.value)} />
        <label className="lbl" htmlFor="rv-text" style={{ marginTop: 12 }}>{L("Your experience", "आपका अनुभव", "آپ کا تجربہ")}</label>
        <textarea id="rv-text" className="inp" style={{ height: 110, padding: 12 }} maxLength={600} value={text} onChange={(e) => setText(e.target.value)} placeholder={L("Tell others what it was like to work with us.", "दूसरों को बताइए कि हमारे साथ काम कैसा रहा।", "دوسروں کو بتائیں کہ ہمارے ساتھ کام کیسا رہا۔")} />
        {err ? <div className="err" role="alert">{err}</div> : null}
        <button type="submit" className="btn btn-primary" style={{ width: "100%", marginTop: 14 }}>{L("Post review", "समीक्षा भेजें", "جائزہ بھیجیں")}</button>
        <p className="rv-note">{L("Your review appears after our team checks it.", "आपकी समीक्षा हमारी टीम की जाँच के बाद दिखेगी।", "آپ کا جائزہ ہماری ٹیم کی جانچ کے بعد دکھایا جائے گا۔")}</p>
      </form>
    </div>
  );
}

export function Reviews() {
  const { lang, t } = useLang();
  const L = (en, hi, ur) => [en, hi, ur][LANG_IDX[lang] ?? 0];
  const [sort, setSort] = useState("rel"), [star, setStar] = useState(0), [shown, setShown] = useState(4);
  const [form, setForm] = useState(false), [thanks, setThanks] = useState(false), [voted, setVoted] = useState(rvVoted), [, bump] = useState(0);
  const all = allReviews();
  const n = all.length;
  const counts = [0, 0, 0, 0, 0, 0];
  all.forEach((r) => { counts[rvRating(r)] += 1; });
  const avg = n ? all.reduce((a, r) => a + rvRating(r), 0) / n : 0;
  const list = (star ? all.filter((r) => rvRating(r) === star) : all.slice());
  const at = (r) => Number(r.at) || 0;
  if (sort === "new") list.sort((a, b) => at(b) - at(a));
  else if (sort === "hi") list.sort((a, b) => rvRating(b) - rvRating(a) || (b.helpful || 0) - (a.helpful || 0));
  else if (sort === "lo") list.sort((a, b) => rvRating(a) - rvRating(b));
  else list.sort((a, b) => (b.helpful || 0) - (a.helpful || 0));
  const helpful = (id) => {
    if (voted.includes(id)) return;
    const d = getDb();
    d.reviews = (d.reviews || SEED_REVIEWS.map((x) => ({ ...x }))).map((r) => (r.id === id ? { ...r, helpful: (r.helpful || 0) + 1 } : r));
    saveDb(d);
    const v = voted.concat(id);
    setVoted(v);
    try { window.localStorage.setItem("pm_helpful", JSON.stringify(v)); } catch (e) { /* memory only */ }
    bump((x) => x + 1);
  };
  return (
    <Section alt id="sec-reviews">
      <SectionHead pill={t("pillRev")} id="reviews" sub={t("subRev")} />
      <div className="rv">
        <div className="rv-sum">
          <div className="rv-big">
            <div className="rv-num" dir="ltr">{n ? avg.toFixed(1) : "–"}</div>
            <Stars value={avg} size={20} />
            <div className="rv-cnt">{L(n + " reviews", n + " समीक्षाएँ", n + " جائزے")}</div>
          </div>
          <div className="rv-bars">
            {[5, 4, 3, 2, 1].map((k) => (
              <button key={k} type="button" className={"rv-bar" + (star === k ? " on" : "")} aria-pressed={star === k} onClick={() => { setStar(star === k ? 0 : k); setShown(4); }}>
                <span className="rv-k" dir="ltr">{k}</span>
                <span className="rv-track"><span className="rv-fill" style={{ width: (n ? (counts[k] / n) * 100 : 0) + "%" }} /></span>
                <span className="rv-c" dir="ltr">{counts[k]}</span>
              </button>
            ))}
          </div>
        </div>
        <div className="rv-tools">
          <button type="button" className="btn btn-primary rv-write" onClick={() => { setThanks(false); setForm(true); }}>{L("Write a review", "समीक्षा लिखें", "جائزہ لکھیں")}</button>
          <label className="rv-sortl"><span>{L("Sort by", "क्रम", "ترتیب")}</span>
            <PickBtn className="rv-pick" noSearch title={L("Sort by", "क्रमबद्ध करें", "ترتیب")} value={sort} onChange={setSort} options={[{ v: "rel", l: L("Most relevant", "सबसे प्रासंगिक", "سب سے متعلقہ") }, { v: "new", l: L("Newest", "सबसे नया", "سب سے نیا") }, { v: "hi", l: L("Highest rating", "सबसे ऊँची रेटिंग", "سب سے اونچی ریٹنگ") }, { v: "lo", l: L("Lowest rating", "सबसे कम रेटिंग", "سب سے کم ریٹنگ") }]} />
          </label>
        </div>
        {thanks && <div className="rv-thanks" role="status">{L("Thank you! Your review will appear after our team checks it.", "धन्यवाद! आपकी समीक्षा हमारी टीम की जाँच के बाद दिखेगी।", "شکریہ! آپ کا جائزہ ہماری ٹیم کی جانچ کے بعد دکھایا جائے گا۔")}</div>}
        {star > 0 && <button type="button" className="rv-clear" onClick={() => setStar(0)}>{"★ " + star + " · " + L("Clear filter", "फ़िल्टर हटाएँ", "فلٹر ہٹائیں")}</button>}
        <div className="rv-list">
          {list.slice(0, shown).map((r) => <ReviewItem key={r.id} r={r} lang={lang} voted={voted.includes(r.id)} onHelpful={helpful} />)}
        </div>
        {list.length > shown && <button type="button" className="btn btn-outline rv-moreb" onClick={() => setShown(shown + 6)}>{L("Show more reviews", "और समीक्षाएँ दिखाएँ", "مزید جائزے دکھائیں")}</button>}
        {!list.length && <div className="card" style={{ textAlign: "center" }}>{L("No reviews yet. Be the first to write one.", "अभी कोई समीक्षा नहीं। पहली समीक्षा आप लिखें।", "ابھی کوئی جائزہ نہیں۔ پہلا جائزہ آپ لکھیں۔")}</div>}
      </div>
      {form && <ReviewForm onClose={() => setForm(false)} onDone={() => { setForm(false); setThanks(true); }} />}
    </Section>
  );
}


export function Newsletter({ toast }) {
  const { t } = useLang();
  const [email, setEmail] = useState(""), [ok, setOk] = useState(false), [err, setErr] = useState("");
  const submit = (e) => {
    e.preventDefault();
    if (!EMAIL_RE.test(email) || !ok) { setErr(!ok ? "Please accept the consent box." : "Enter a valid email."); return; }
    const done = () => { setEmail(""); setErr(""); };
    if (!REMOTE) { const db = getDb(); db.subscribers = (db.subscribers || []).concat({ email, at: Date.now() }); toast(saveDb(db).ok ? "Subscribed" : t("storageFull")); done(); return; }
    submitRemote("subscribe", { p_email: email }).then((res) => { if (!res.ok) { setErr(res.error); return; } toast(res.queued ? QUEUED_MSG : "Subscribed"); done(); });
  };
  return (
    <Section id="sec-news">
      <form onSubmit={submit} noValidate style={{ maxWidth: 420, margin: "0 auto", textAlign: "center" }}>
        <span className="tile" style={{ width: 56, height: 56, borderRadius: 16, margin: "0 auto 16px" }}><Icon name="mail" size={26} /></span>
        <Heading id="news" /><p className="sub">{t("newsLine")}</p>
        <input id="news-email" className="inp" type="email" dir="ltr" placeholder={t("emailPh")} aria-label={tr("Email")} value={email} onChange={(e) => setEmail(e.target.value)} />
        {err && <div style={{ color: "var(--error)", fontSize: 12.8, textAlign: "start" }}>{err}</div>}
        <button type="submit" className="btn" style={{ background: "var(--teal)", color: "#fff", height: 44, padding: "0 28px", marginTop: 12 }}>{t("subscribe")}</button>
        <p style={{ fontSize: 14, color: "var(--muted)" }}>{t("noSpam")}</p>
        <label style={{ fontSize: 13 }}><input id="news-consent" type="checkbox" checked={ok} onChange={(e) => setOk(e.target.checked)} /> {tr("I agree to receive updates.")}</label>
      </form>
    </Section>
  );
}

export function SuccessPage() {
  const closed = (getDb().requests || []).filter((r) => r.status === 5);
  return (
    <div>
      <PageHead pill="Success stories" plain="Trusted by " hl="owners." />
      {closed.length > 0 && (
        <Section id="sec-closed">
          <h3 className="ct" style={{ textAlign: "center", marginTop: 0 }}>Closed deals: {closed.length}</h3>
          <div className="grid">{closed.map((r) => <div className="card" key={r.id}><b style={{ color: "var(--ink)" }}>{catName(r.category, "en")}</b><p className="cb">{r.block}, Saharsa · {r.area} {r.unit}</p><span className="mini v"><Icon name="check" size={12} />{tr("Closed")}</span></div>)}</div>
        </Section>
      )}
      <Reviews />
    </div>
  );
}
