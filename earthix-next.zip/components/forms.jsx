"use client";

import React, { useState, useEffect, useLayoutEffect, useRef, useCallback, useMemo, useContext, createContext, startTransition, useId } from "react";
import { LANG_NOW, tr } from "@/lib/i18n";
import { useLang } from "@/lib/lang";
import { LANG_IDX } from "@/lib/brand";
import { DOCS, DOC_NOTE, FIELDS, FORM_CHIPS, FORM_META, FUND_OPTS, LEGAL_KEYS, NEXT_STEPS, PURPOSE_OPTS, TIMELINE_OPTS, detailKeys, ex, hint, scrollToError } from "@/lib/forms";
import { Err, Field, Icon, PageHead, Section, SectionHead, WhatsAppIcon } from "@/components/common";
import { CATEGORIES, catName, waLink } from "@/lib/config";
import { openMeeting, openPicker } from "@/lib/dom";
import { LOCATION_DATA, getLocations } from "@/lib/locations";
import { MOBILE_RE, UNITS, cleanMobile, fmtINR, fmtNum, makeId, toSqft } from "@/lib/helpers";
import { acctEmail, getDb, saveDb } from "@/lib/store";
import { QUEUED_MSG, REMOTE, reqPayload, submitRemote } from "@/lib/backend";
import { scrollTopNow, L } from "@/lib/nav";
import { waText } from "@/lib/content";


export function DetailFields({ kind, category, value, onChange, errors }) {
  const { lang } = useLang();
  const li = LANG_IDX[lang] ?? 0;
  const e = errors || {};
  const d = value || {};
  const keys = detailKeys(kind, category);
  const set = (k, v) => onChange({ ...d, [k]: v });
  const one = (k) => {
    const f = FIELDS[k];
    const lbl = (f.l[li] || f.l[0]) + (f.req && kind === "sell" ? " *" : "");
    const id = "dt-" + k;
    if (f.type === "sel" && f.opts.length <= 5) {
      return (
        <div className="fld" key={k}>
          <div className="lbl" id={id + "-l"}>{lbl}</div>
          <div className="chiprow" role="group" aria-labelledby={id + "-l"}>
            {f.opts.map((o) => { const on = d[k] === o; return <button key={o} type="button" className="areachip" aria-pressed={on} style={{ cursor: "pointer", background: on ? "var(--teal-soft)" : "#fff", fontWeight: on ? 700 : undefined }} onClick={() => set(k, on ? "" : o)}>{o}</button>; })}
          </div>
          <Err m={e[k]} />
        </div>
      );
    }
    if (f.type === "sel") return <SearchSelect key={k} id={id} label={lbl} value={d[k] || ""} options={f.opts} error={e[k]} onChange={(v) => set(k, v)} />;
    const isNum = f.type === "num";
    return <Field key={k} id={id} label={lbl} error={e[k]}><input id={id} className="inp" dir={isNum ? "ltr" : undefined} inputMode={isNum ? "decimal" : undefined} maxLength={isNum ? 12 : 80} value={d[k] || ""} onChange={(ev) => set(k, isNum ? ev.target.value.replace(/[^\d.]/g, "") : ev.target.value)} /></Field>;
  };
  if (!category) return <p className="hint">{["Please choose a category in step 1 first.", "पहले चरण 1 में श्रेणी चुनें।", "پہلے مرحلہ 1 میں زمرہ منتخب کریں۔"][li]}</p>;
  const legal = keys.filter((k) => LEGAL_KEYS.includes(k)), prop = keys.filter((k) => !LEGAL_KEYS.includes(k));
  const buy = kind === "buy";
  const H1 = buy ? ["What you prefer", "आपकी पसंद", "آپ کی پسند"] : ["Property details", "प्रॉपर्टी का विवरण", "پراپرٹی کی تفصیل"];
  const H2 = buy ? ["Papers you want", "कागज़ात जो चाहिए", "مطلوبہ کاغذات"] : ["Papers and ownership", "कागज़ात और मालिकाना हक़", "کاغذات اور ملکیت"];
  return (
    <div className="dsec">
      <p className="dhead">{catName(category, lang)}</p>
      {prop.length > 0 && <div><p className="dgrp" style={{ borderTop: "none", paddingTop: 0, marginTop: 6 }}>{H1[li]}</p>{prop.map(one)}</div>}
      {legal.length > 0 && <div><p className="dgrp">{H2[li]}</p>{legal.map(one)}</div>}
    </div>
  );
}

export function FormShell({ kind, step, children }) {
  const { lang } = useLang();
  const i = LANG_IDX[lang] ?? 0;
  const m = FORM_META[kind];
  return (
    <div className="wrap fshell">
      <div className={"formhero " + kind}>
        <span className="pill">{m.pill[i]}</span>
        <h1 className="h1 bigh"><span>{m.plain[i]}</span><span className="hl2">{m.hl[i]}</span></h1>
        <p className="sub" style={{ maxWidth: 480 }}>{m.sub[i]}</p>
        <div className="fchips">{FORM_CHIPS.map((c) => <span key={c[0]} className="fchip"><Icon name={c[3]} size={16} />{c[i]}</span>)}</div>
      </div>
      <ol className={"stepper " + kind} aria-label="Steps">
        {m.steps.map((s, k) => <li key={k} className={k === step ? "cur" : k < step ? "done" : ""} aria-current={k === step ? "step" : undefined}><b>{k < step ? "✓" : k + 1}</b><span>{s[i]}</span></li>)}
      </ol>
      <div id="form-top" />
      {children}
      <div className="nextbox">
        <b>{[ "What happens next", "आगे क्या होगा", "آگے کیا ہوگا"][i]}</b>
        <ol>{NEXT_STEPS.map((x) => <li key={x[0]}>{x[i]}</li>)}</ol>
      </div>
    </div>
  );
}

export function StepHead({ kind, step }) {
  const { lang } = useLang();
  const i = LANG_IDX[lang] ?? 0;
  const m = FORM_META[kind];
  return (
    <div className={"stephead " + kind}>
      <p className="stepno">{["Step", "चरण", "مرحلہ"][i]} {step + 1} / {m.steps.length}</p>
      <h2>{m.titles[step][i]}</h2>
      <p>{m.descs[step][i]}</p>
    </div>
  );
}

// ---------- LOCATION PICKER: tap a field, a sheet opens with search. Works the same on phone and desktop. ----------
export function PickerSheet({ title, options, value, onPick, onClose, emptyText, searchPh }) {
  const [q, setQ] = useState("");
  const inputRef = useRef(null);
  const opts = useMemo(() => options.map((o) => (typeof o === "string" ? { v: o, l: o } : o)), [options]);
  const items = useMemo(() => { const n = q.trim().toLowerCase(); return (n ? opts.filter((o) => o.l.toLowerCase().includes(n)) : opts).slice(0, 200); }, [q, opts]);
  const showSearch = opts.length > 8;
  useEffect(() => {
    const fine = window.matchMedia && window.matchMedia("(pointer: fine)").matches;
    if (fine && showSearch && inputRef.current) inputRef.current.focus();
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    // Esc closes only this list (capture phase), never the form or popup behind it
    const onKey = (e) => { if (e.key === "Escape") { e.stopPropagation(); onClose(); } };
    document.addEventListener("keydown", onKey, true);
    return () => { document.body.style.overflow = prev; document.removeEventListener("keydown", onKey, true); };
  }, [onClose, showSearch]);
  return (
    <div>
      <div className="sheet-bg" onPointerDown={onClose} aria-hidden="true" />
      <div className="sheet" role="dialog" aria-modal="true" aria-label={title}>
        <div className="sheet-head"><b>{title}</b><button type="button" className="burger" style={{ width: 40, height: 40 }} aria-label={tr("Close")} onClick={onClose}><Icon name="close" size={20} /></button></div>
        {showSearch && <input ref={inputRef} className="inp" type="search" autoComplete="off" placeholder={searchPh} aria-label={searchPh} value={q} onChange={(e) => setQ(e.target.value)} />}
        <div className="sheet-list" role="listbox">
          {items.length ? items.map((o) => <button key={o.v === "" ? "__all" : o.v} type="button" role="option" aria-selected={o.v === value} className={"sheet-opt" + (o.v === value ? " sel" : "")} onClick={() => onPick(o.v)}><span className="radio" aria-hidden="true"><i /></span><span className="otxt">{o.l}</span></button>) : <div className="sheet-empty">{emptyText}</div>}
        </div>
      </div>
    </div>
  );
}

export function PickerHost() {
  const [cfg, setCfg] = useState(null);
  useEffect(() => { const on = (e) => setCfg(e.detail); window.addEventListener("pm-picker", on); return () => window.removeEventListener("pm-picker", on); }, []);
  const close = useCallback(() => { setCfg((c) => { if (c && c.onClose) c.onClose(); return null; }); }, []);
  if (!cfg) return null;
  return <PickerSheet title={cfg.title} options={cfg.options} value={cfg.value} emptyText={cfg.emptyText} searchPh={cfg.searchPh} onClose={close} onPick={(v) => { cfg.onPick(v); close(); }} />;
}

export function SearchSelect({ id, label, value, options, onChange, placeholder, disabled, error, emptyText, searchPh, hint: h, compact, ariaLabel }) {
  const [open, setOpen] = useState(false);
  const li = LANG_IDX[LANG_NOW.v] ?? 0;
  const ph = placeholder || ["Tap to choose", "चुनने के लिए दबाएँ", "منتخب کرنے کے لیے دبائیں"][li];
  const cur = options.map((o) => (typeof o === "string" ? { v: o, l: o } : o)).find((o) => o.v === value);
  const show = () => {
    setOpen(true);
    openPicker({ title: label || ariaLabel || "", options, value, onPick: onChange, onClose: () => setOpen(false), emptyText: emptyText || ["No match found", "कोई मेल नहीं मिला", "کوئی نتیجہ نہیں ملا"][li], searchPh: searchPh || ["Type to search", "खोजने के लिए लिखें", "تلاش کے لیے لکھیں"][li] });
  };
  return (
    <div className={compact ? "fld pickc" : "fld"}>
      {label ? <label className="lbl" htmlFor={id}>{label}</label> : null}
      {h ? <div className="hint">{h}</div> : null}
      <button type="button" id={id} aria-label={ariaLabel} className={"inp pick" + (cur ? "" : " empty")} disabled={disabled} aria-haspopup="listbox" aria-expanded={open} onClick={show}>
        <span>{cur ? cur.l : ph}</span><span aria-hidden="true">▾</span>
      </button>
      {value && !disabled && !compact ? <button type="button" className="pick-x" aria-label={"Clear " + (label || "")} onClick={() => onChange("")}>✕</button> : null}
      <Err m={error} />
    </div>
  );
}

// Small button that opens the same white, saffron-radio list as SearchSelect (no native dropdown anywhere).
export function PickBtn({ id, value, options, onChange, title, ariaLabel, className, style, noSearch }) {
  const [open, setOpen] = useState(false);
  const li = LANG_IDX[LANG_NOW.v] ?? 0;
  const opts = options.map((o) => (typeof o === "string" ? { v: o, l: o } : o));
  const cur = opts.find((o) => String(o.v) === String(value));
  const show = () => {
    setOpen(true);
    openPicker({ title: title || ariaLabel || "", options: opts, value, onPick: onChange, onClose: () => setOpen(false), emptyText: ["No match found", "कोई मेल नहीं मिला", "کوئی میل نہیں ملا"][li], searchPh: noSearch ? "" : ["Type to search", "खोजने के लिए लिखें", "تلاش کے لیے لکھیں"][li] });
  };
  return (
    <button type="button" id={id} aria-label={ariaLabel || title} aria-haspopup="listbox" aria-expanded={open} className={"inp pick " + (className || "")} style={style} onClick={show}>
      <span>{cur ? cur.l : ""}</span><span aria-hidden="true">▾</span>
    </button>
  );
}

export function LocationPicker({ value, onChange, errors }) {
  const { lang } = useLang();
  const L = (en, hi, ur) => [en, hi, ur][LANG_IDX[lang] ?? 0];
  const e = errors || {};
  const d = value.district, b = value.block, p = value.panchayat;
  const blocks = (d && LOCATION_DATA[d]) || [];
  const det = getLocations();
  const pmap = (d && b && det[d] && det[d][b]) || {};
  const panchayats = useMemo(() => Object.keys(pmap).sort(), [pmap]);
  const villages = (p && pmap[p]) || [];
  const none = L("No match found", "कोई मेल नहीं मिला", "کوئی نتیجہ نہیں ملا");
  const search = L("Type to search", "खोजने के लिए लिखें", "تلاش کے لیے لکھیں");
  const choose = L("Tap to choose", "चुनने के लिए दबाएँ", "منتخب کرنے کے لیے دبائیں");
  const set = (patch) => onChange({ district: d, block: b, panchayat: p, village: value.village, ...patch });
  const hasP = panchayats.length > 0, hasV = villages.length > 0;
  return (
    <div>
      <SearchSelect id="loc-district" label={L("District", "ज़िला", "ضلع")} value={d} options={Object.keys(LOCATION_DATA)} placeholder={choose} emptyText={none} searchPh={search} error={e.district} onChange={(v) => set({ district: v, block: "", panchayat: "", village: "" })} />
      <SearchSelect id="loc-block" label={L("Block / Anchal", "ब्लॉक / अंचल", "بلاک / انچل")} value={b} options={blocks} disabled={!d} placeholder={d ? choose : L("Choose district first", "पहले ज़िला चुनें", "پہلے ضلع منتخب کریں")} emptyText={none} searchPh={search} error={e.block} onChange={(v) => set({ block: v, panchayat: "", village: "" })} />
      {hasP
        ? <SearchSelect id="loc-panchayat" label={L("Panchayat / Halka", "पंचायत / हल्का", "پنچایت / حلقہ")} value={p} options={panchayats} disabled={!b} placeholder={choose} emptyText={none} searchPh={search} error={e.panchayat} onChange={(v) => set({ panchayat: v, village: "" })} />
        : <Field id="loc-panchayat" label={L("Panchayat / Halka", "पंचायत / हल्का", "پنچایت / حلقہ")} hint={b ? L("Type the name of your Panchayat. Example: Kahara", "अपनी पंचायत का नाम लिखें। जैसे: कहारा", "اپنی پنچایت کا نام لکھیں۔ مثال: کہارا") : null} error={e.panchayat}><input id="loc-panchayat" className="inp" disabled={!b} autoComplete="off" placeholder={b ? L("e.g. Kahara", "जैसे: कहारा", "مثال: کہارا") : L("Choose block first", "पहले ब्लॉक चुनें", "پہلے بلاک منتخب کریں")} value={p} onChange={(ev) => set({ panchayat: ev.target.value })} /></Field>}
      {hasV
        ? <SearchSelect id="loc-village" label={L("Village / Mauja", "गाँव / मौजा", "گاؤں / موضع")} value={value.village} options={villages} disabled={!p} placeholder={choose} emptyText={none} searchPh={search} error={e.village} onChange={(v) => set({ village: v })} />
        : <Field id="loc-village" label={L("Village / Mauja", "गाँव / मौजा", "گاؤں / موضع")} hint={p ? L("Type the name of your Village or Mauja.", "अपने गाँव या मौजा का नाम लिखें।", "اپنے گاؤں یا موضع کا نام لکھیں۔") : null} error={e.village}><input id="loc-village" className="inp" disabled={!p} autoComplete="off" placeholder={p ? L("e.g. Bairiya", "जैसे: बैरिया", "مثال: بیریا") : L("Fill Panchayat first", "पहले पंचायत भरें", "پہلے پنچایت بھریں")} value={value.village} onChange={(ev) => set({ village: ev.target.value })} /></Field>}
    </div>
  );
}

export function RequirementSection() {
  const { lang } = useLang();
  const i = LANG_IDX[lang] ?? 0;
  const cards = [
    { cls: "buy", href: "#/buy-request", icon: "home", title: ["I want to BUY", "मुझे खरीदना है", "مجھے خریدنا ہے"], pts: [["Tell us your budget and area", "अपना बजट और क्षेत्र बताइए", "اپنا بجٹ اور علاقہ بتائیے"], ["We find private matches for you", "हम आपके लिए निजी मेल ढूँढते हैं", "ہم آپ کے لیے نجی میچ ڈھونڈتے ہیں"], ["No public listing, no pressure", "कोई सार्वजनिक लिस्टिंग नहीं, कोई दबाव नहीं", "کوئی عوامی لسٹنگ نہیں، کوئی دباؤ نہیں"]], btn: ["Share buy requirement ›", "खरीद की ज़रूरत बताएँ ›", "خریداری کی ضرورت بتائیں ›"] },
    { cls: "sell", href: "#/sell", icon: "rupee", title: ["I want to SELL", "मुझे बेचना है", "مجھے بیچنا ہے"], pts: [["Tell us what you own and where", "बताइए आपके पास क्या है और कहाँ", "بتائیے آپ کے پاس کیا ہے اور کہاں"], ["We verify papers and find buyers", "हम कागज़ जाँचते हैं और खरीदार ढूँढते हैं", "ہم کاغذات جانچتے ہیں اور خریدار ڈھونڈتے ہیں"], ["Commission told upfront, in writing", "कमीशन पहले, लिखित में बताया जाता है", "کمیشن پہلے، تحریری بتایا جاتا ہے"]], btn: ["Submit sell request ›", "बिक्री अनुरोध भेजें ›", "فروخت کی درخواست بھیجیں ›"] },
  ];
  return (
    <Section id="sec-requirement">
      <SectionHead pill={["Share Your Need", "अपनी ज़रूरत बताएँ", "اپنی ضرورت بتائیں"][i]} id="req" sub={["Fill a short form. We call you, nothing is published.", "एक छोटा फ़ॉर्म भरें। हम आपको कॉल करेंगे, कुछ भी सार्वजनिक नहीं होता।", "ایک مختصر فارم بھریں۔ ہم آپ کو کال کریں گے، کچھ بھی عوامی نہیں ہوتا۔"][i]} />
      <div className="reqgrid">
        {cards.map((c, ci) => {
          const extra = c.cls === "buy"
            ? { badge: ["For buyers", "खरीदारों के लिए", "خریداروں کے لیے"], foot: ["Nothing is published. First meeting free.", "कुछ भी प्रकाशित नहीं होता। पहली मीटिंग मुफ़्त।", "کچھ بھی شائع نہیں ہوتا۔ پہلی میٹنگ مفت۔"], bubs: [[10, 9, 7, 0], [26, 14, 9, 1.4], [44, 8, 6.5, 3], [62, 16, 10, 0.6], [78, 10, 8, 2.2], [91, 7, 7, 4], [36, 6, 8.5, 5.2]] }
            : { badge: ["For sellers", "विक्रेताओं के लिए", "بیچنے والوں کے لیے"], foot: ["Commission told upfront, in writing.", "कमीशन पहले ही, लिखित में बताया जाता है।", "کمیشن پہلے ہی، تحریری طور پر بتایا جاتا ہے۔"], bubs: [[88, 9, 7.5, 0.4], [70, 14, 9, 2], [52, 8, 6.5, 3.6], [34, 16, 10, 1], [18, 10, 8, 2.8], [6, 7, 7, 4.4], [60, 6, 8.5, 5.4]] };
          return (
            <div key={c.cls} className={"reqcard " + c.cls}>
              <div className="bubwrap" aria-hidden="true">{extra.bubs.map((b, k) => <span key={k} className="bub" style={{ "--l": b[0] + "%", "--s": b[1] + "px", "--d": b[2] + "s", "--dl": b[3] + "s" }} />)}</div>
              <span className="reqmark" aria-hidden="true"><Icon name={c.icon} size={120} /></span>
              <div className="reqtop">
                <span className="reqicon"><Icon name={c.icon} size={26} /></span>
                <div className="reqttl">
                  <span className="buycta-badge"><Icon name="sparkle" size={12} />{extra.badge[i]}</span>
                  <h3>{c.title[i]}</h3>
                </div>
              </div>
              <div className="reqlist">{c.pts.map((x, k) => <div key={x[0]} className="reqpt" style={{ "--n": k }}><span className="reqtick"><Icon name="check" size={13} /></span><span>{x[i]}</span></div>)}</div>
              <a className="btn reqbtn" href={L(c.href)}><span>{c.btn[i]}</span></a>
              <div className="reqfoot"><Icon name="shield" size={14} />{extra.foot[i]}</div>
            </div>
          );
        })}
      </div>
    </Section>
  );
}

export function BuyRequestPage({ settings, toast }) {
  const { lang, t } = useLang();
  const L = (en, hi, ur) => [en, hi, ur][LANG_IDX[lang] ?? 0];
  const [step, setStep] = useState(0);
  const [f, setF] = useState({ category: "", details: {}, purpose: "", district: "", block: "", panchayat: "", village: "", areaMin: "", areaMax: "", unit: "Katha", budgetMin: "", budgetMax: "", timeline: "", funding: "", name: "", mobile: "", notes: "", consent: false });
  const [err, setErr] = useState({}), [dup, setDup] = useState(false), [done, setDone] = useState(null), [busy, setBusy] = useState(false);
  const up = (k) => (e) => { setDup(false); setF((s) => ({ ...s, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value })); };
  const num = (k) => (e) => { setDup(false); setF((s) => ({ ...s, [k]: e.target.value.replace(/[^\d.]/g, "") })); };
  const validate = (s) => {
    const er = {};
    if (s === 0) { if (!f.category) er.category = "Choose what you want to buy."; if (!f.purpose) er.purpose = "Choose the purpose."; }
    if (s === 1) { if (!f.district) er.district = "Choose a district."; if (!f.block) er.block = "Choose a block / anchal."; }
    if (s === 2) {
      if (!(Number(f.budgetMax) > 0)) er.budgetMax = "Enter your maximum budget in rupees.";
      else if (Number(f.budgetMin) > Number(f.budgetMax)) er.budgetMin = "Minimum cannot be above the maximum.";
      if (f.areaMin && f.areaMax && Number(f.areaMin) > Number(f.areaMax)) er.areaMin = "Minimum cannot be above the maximum.";
    }
    if (s === 4 && !f.timeline) er.timeline = "Choose when you want to buy.";
    if (s === 5) { if (f.name.trim().length < 2) er.name = "Enter your name."; if (!MOBILE_RE.test(f.mobile)) er.mobile = "Enter a valid 10-digit mobile number."; if (!f.consent) er.consent = "Please accept to continue."; }
    return er;
  };
  const next = () => { const er = validate(step); setErr(er); if (!Object.keys(er).length) setStep(step + 1); else setTimeout(scrollToError, 40); };
  const submit = (e) => {
    e.preventDefault();
    const er = validate(5); setErr(er);
    if (Object.keys(er).length) { setTimeout(scrollToError, 40); return; }
    const db = getDb();
    const isDup = (db.requests || []).some((r) => r.type === "buy" && r.mobile === f.mobile && r.category === f.category && r.district === f.district && r.block === f.block);
    if (isDup && !dup) { setDup(true); return; }
    const req = { id: makeId("REQ"), type: "buy", acct: acctEmail(), category: f.category, details: f.details, purpose: f.purpose, district: f.district, block: f.block, panchayat: f.panchayat.trim(), village: f.village.trim(), locality: f.village.trim() || f.panchayat.trim(), areaMin: f.areaMin, areaMax: f.areaMax, area: Number(f.areaMax || f.areaMin || 0), unit: f.unit, budgetMin: f.budgetMin, budgetMax: f.budgetMax, price: Number(f.budgetMax), timeline: f.timeline, funding: f.funding, name: f.name.trim(), mobile: f.mobile, notes: f.notes, status: 0, at: Date.now() };
    const finish = () => { db.requests = (db.requests || []).concat(req); if (!saveDb(db).ok) { toast(t("storageFull")); return; } setDone(req); };
    if (!REMOTE) { finish(); return; }
    setBusy(true);
    submitRemote("submit_request", { p_data: reqPayload(req) }).then((res) => { setBusy(false); if (!res.ok) { toast(res.error); return; } finish(); if (res.queued) toast(QUEUED_MSG); });
  };
  useEffect(() => { if (done) scrollTopNow(); }, [done]);
  const stepRef = useRef(true);
  useEffect(() => { if (stepRef.current) { stepRef.current = false; return; } const el = document.getElementById("form-top"); if (el && el.scrollIntoView) el.scrollIntoView({ block: "start" }); }, [step]);
  const sqMax = toSqft(f.areaMax, f.unit, settings.sqftPerKatha);
  const Sel = ({ id, label, k, opts, error, h }) => <SearchSelect id={id} label={label} value={f[k]} options={opts} error={error} hint={h} onChange={(v) => { setDup(false); setF((s) => ({ ...s, [k]: v })); }} />;
  if (done) {
    return (
      <div className="wrap" style={{ maxWidth: 560, paddingBottom: 48 }}>
        <PageHead pill={t("navBuy")} plain={L("Requirement ", "आपकी ज़रूरत ", "آپ کی ضرورت ")} hl={L("received.", "मिल गई।", "مل گئی۔")} />
        <div className="card">
          <p className="cb"><b>{L("Request ID:", "अनुरोध ID:", "درخواست ID:")}</b> <span dir="ltr">{done.id}</span></p>
          <p className="cb">{L("We will call you on your mobile to understand your need and share matching properties privately. Nothing is published.", "हम आपके मोबाइल पर कॉल करके आपकी ज़रूरत समझेंगे और मेल खाती प्रॉपर्टी निजी तौर पर दिखाएँगे। कुछ भी सार्वजनिक नहीं होता।", "ہم آپ کے موبائل پر کال کر کے آپ کی ضرورت سمجھیں گے اور موزوں پراپرٹی نجی طور پر دکھائیں گے۔ کچھ بھی عوامی نہیں ہوتا۔")}</p>
          <b style={{ color: "var(--ink)" }}>{L("Documents to bring to your meeting", "मीटिंग में लाने वाले दस्तावेज़", "میٹنگ میں لانے والے کاغذات")}</b>
          <ul style={{ paddingInlineStart: 18, fontSize: 14 }}>{((settings.docLists && settings.docLists.buy) || DOCS.buy).map((d) => <li key={d}>{d}</li>)}</ul>
          <p style={{ fontSize: 12.5 }}>{DOC_NOTE}</p>
          <div className="stack">
            <a className="btn btn-wa" href={L(waLink(settings.whatsapp, waText("buy", done, lang)))} target="_blank" rel="noopener noreferrer"><WhatsAppIcon size={18} />{L("Confirm on WhatsApp", "व्हाट्सऐप पर पुष्टि करें", "واٹس ایپ پر تصدیق کریں")}</a>
            <button type="button" className="btn btn-primary" onClick={() => openMeeting("buy")}>{t("bookMeeting")}</button>
            <a className="btn btn-outline" href={L("#/track")}>{L("Track my request", "मेरा अनुरोध ट्रैक करें", "میری درخواست ٹریک کریں")}</a>
            <a className="btn btn-outline" href={L("#/")}>{L("Back to home", "होम पर वापस जाएँ", "ہوم پر واپس جائیں")}</a>
          </div>
        </div>
      </div>
    );
  }
  return (
    <FormShell kind="buy" step={step}>
      <form className="card formcard" onSubmit={submit} noValidate>
        <StepHead kind="buy" step={step} />
        {step === 0 && <div>
          <SearchSelect id="b-cat" label={L("What do you want to buy or rent?", "आप क्या खरीदना या किराये पर लेना चाहते हैं?", "آپ کیا خریدنا یا کرائے پر لینا چاہتے ہیں؟")} value={f.category} options={CATEGORIES.map((c) => ({ v: c.slug, l: c.name[LANG_IDX[lang]] }))} error={err.category} onChange={(v) => { setDup(false); setF((s) => ({ ...s, category: v, details: s.category === v ? s.details : {} })); }} />
          {Sel({ id: "b-purpose", label: L("Why do you need it?", "आपको यह क्यों चाहिए?", "آپ کو یہ کیوں چاہیے؟"), k: "purpose", opts: PURPOSE_OPTS, error: err.purpose })}
        </div>}
        {step === 1 && <div>
          <p className="hint" style={{ marginTop: 8 }}>{L("Choose where you want the property. Panchayat and Village are optional: leave them empty if you are flexible.", "बताइए प्रॉपर्टी कहाँ चाहिए। पंचायत और गाँव वैकल्पिक हैं: लचीले हों तो खाली छोड़ दें।", "بتائیے پراپرٹی کہاں چاہیے۔ پنچایت اور گاؤں اختیاری ہیں: لچک ہو تو خالی چھوڑ دیں۔")}</p>
          <LocationPicker value={f} errors={err} onChange={(patch) => { setDup(false); setF((x) => ({ ...x, ...patch })); }} />
        </div>}
        {step === 2 && <div>
          <Field id="b-bmax" label={L("Maximum budget (₹)", "अधिकतम बजट (₹)", "زیادہ سے زیادہ بجٹ (₹)")} hint={hint("budget")} error={err.budgetMax}><input id="b-bmax" className="inp" dir="ltr" inputMode="numeric" placeholder={ex("budget")} value={f.budgetMax} onChange={num("budgetMax")} /></Field>
          {Number(f.budgetMax) > 0 && <p className="hint" dir="ltr">= {fmtINR(f.budgetMax)}</p>}
          <Field id="b-bmin" label={L("Minimum budget (₹, optional)", "न्यूनतम बजट (₹, वैकल्पिक)", "کم از کم بجٹ (₹، اختیاری)")} error={err.budgetMin}><input id="b-bmin" className="inp" dir="ltr" inputMode="numeric" placeholder={ex("amt")} value={f.budgetMin} onChange={num("budgetMin")} /></Field>
          <Field id="b-amin" label={L("Area you need (optional)", "आपको कितना क्षेत्रफल चाहिए (वैकल्पिक)", "آپ کو کتنا رقبہ چاہیے (اختیاری)")} hint={hint("area")} error={err.areaMin}>
            <div style={{ display: "flex", gap: 8 }}>
              <input id="b-amin" className="inp" dir="ltr" inputMode="decimal" placeholder={L("From, e.g. 3", "से, जैसे: 3", "سے، مثال: 3")} value={f.areaMin} onChange={num("areaMin")} />
              <input id="b-amax" className="inp" dir="ltr" inputMode="decimal" aria-label={L("To", "तक", "تک")} placeholder={L("To, e.g. 6", "तक, जैसे: 6", "تک، مثال: 6")} value={f.areaMax} onChange={num("areaMax")} />
            </div>
          </Field>
          <SearchSelect id="b-unit" label={L("Unit", "इकाई", "اکائی")} value={f.unit} options={UNITS} onChange={(v) => setF((s) => ({ ...s, unit: v }))} />
          {sqMax ? <p className="hint" dir="ltr">≈ {fmtNum(sqMax, 0)} Sq ft ({L("upper limit", "ऊपरी सीमा", "بالائی حد")})</p> : null}
        </div>}
        {step === 3 && <DetailFields kind="buy" category={f.category} value={f.details} errors={err} onChange={(dt) => { setDup(false); setF((x) => ({ ...x, details: dt })); }} />}
        {step === 4 && <div>
          {Sel({ id: "b-time", label: L("When do you want to buy?", "आप कब खरीदना चाहते हैं?", "آپ کب خریدنا چاہتے ہیں؟"), k: "timeline", opts: TIMELINE_OPTS, error: err.timeline })}
          {Sel({ id: "b-fund", label: L("How will you pay? (optional)", "भुगतान कैसे करेंगे? (वैकल्पिक)", "ادائیگی کیسے کریں گے؟ (اختیاری)"), k: "funding", opts: FUND_OPTS })}
          <Field id="b-notes" label={L("Anything else we should know? (optional)", "और कुछ बताना है? (वैकल्पिक)", "کچھ اور بتانا ہے؟ (اختیاری)")} hint={hint("need")}><textarea id="b-notes" className="inp" style={{ height: 90, padding: 12 }} placeholder={ex("need")} value={f.notes} onChange={up("notes")} /></Field>
        </div>}
        {step === 5 && <div>
          <Field id="b-name" label={L("Your name", "आपका नाम", "آپ کا نام")} error={err.name}><input id="b-name" className="inp" autoComplete="name" placeholder={ex("name")} value={f.name} onChange={up("name")} /></Field>
          <Field id="b-mobile" label={L("Mobile number", "मोबाइल नंबर", "موبائل نمبر")} hint={hint("mobile")} error={err.mobile}><input id="b-mobile" className="inp" dir="ltr" inputMode="numeric" autoComplete="tel-national" placeholder={ex("mobile")} value={f.mobile} onChange={(e) => { setDup(false); setF((s) => ({ ...s, mobile: cleanMobile(e.target.value) })); }} /></Field>
          <label className="chk"><input id="b-consent" type="checkbox" checked={f.consent} onChange={up("consent")} /> {L("I agree to be contacted privately.", "मैं निजी तौर पर संपर्क किए जाने से सहमत हूँ।", "میں نجی طور پر رابطے سے متفق ہوں۔")}</label>
          <Err m={err.consent} />
          {dup && <div className="err" role="alert">{L("A similar request from this number already exists. Press Submit again to send it anyway.", "इस नंबर से मिलता-जुलता अनुरोध पहले से है। फिर भी भेजना हो तो दोबारा Submit दबाएँ।", "اس نمبر سے ملتی جلتی درخواست پہلے سے موجود ہے۔ پھر بھی بھیجنی ہو تو دوبارہ Submit دبائیں۔")}</div>}
        </div>}
        <div style={{ display: "flex", gap: 10, marginTop: 18 }}>
          {step > 0 && <button key="back" type="button" className="btn btn-outline" style={{ flex: 1 }} onClick={() => { setErr({}); setStep(step - 1); }}>{L("Back", "पीछे", "واپس")}</button>}
          {step < 5 ? <button key="next" type="button" className="btn btn-primary" style={{ flex: 1 }} onClick={next}>{L("Next", "आगे", "آگے")} ›</button> : <button key="submit" type="submit" disabled={busy} className="btn btn-primary" style={{ flex: 1 }}>{L("Submit requirement", "ज़रूरत भेजें", "ضرورت بھیجیں")}</button>}
        </div>
      </form>
    </FormShell>
  );
}

// ---------- BUY PAGE: big "not finding the right property?" banner ----------
export function BuyCta() {
  const { lang } = useLang();
  const i = LANG_IDX[lang] ?? 0;
  const pts = [["Takes 2 minutes", "सिर्फ़ 2 मिनट", "صرف 2 منٹ"], ["Verified team only", "सिर्फ़ सत्यापित टीम", "صرف تصدیق شدہ ٹیم"], ["First meeting free", "पहली मीटिंग मुफ़्त", "پہلی میٹنگ مفت"]];
  const bubbles = [[14, 8, 7, 0], [30, 14, 9, 1.6], [48, 9, 6.5, 3.2], [64, 18, 10, 0.8], [80, 11, 8, 2.4], [92, 7, 7.5, 4.2], [22, 6, 8.5, 5], [70, 6, 6, 3.8]];
  return (
    <section className="buycta" aria-label={["Tell us your requirement", "अपनी ज़रूरत बताइए", "اپنی ضرورت بتائیے"][i]}>
      <div className="bubwrap" aria-hidden="true">{bubbles.map((b, k) => <span key={k} className="bub" style={{ "--l": b[0] + "%", "--s": b[1] + "px", "--d": b[2] + "s", "--dl": b[3] + "s" }} />)}</div>
      <div className="buycta-top">
        <span className="reqicon"><Icon name="users" size={24} /></span>
        <div className="buycta-ttl">
          <span className="buycta-badge"><Icon name="sparkle" size={12} />{["Private matching", "निजी मैचिंग", "نجی میچنگ"][i]}</span>
          <h2>{["Not finding the right property?", "सही प्रॉपर्टी नहीं मिली?", "صحیح پراپرٹی نہیں ملی؟"][i]}</h2>
        </div>
      </div>
      <p className="buycta-lead">{["These are only samples. Tell us the type, place and budget, and we will find your match privately.", "ये सिर्फ़ नमूने हैं। प्रकार, जगह और बजट बताइए, हम आपके लिए निजी तौर पर मेल ढूँढेंगे।", "یہ صرف نمونے ہیں۔ قسم، جگہ اور بجٹ بتائیے، ہم آپ کے لیے نجی طور پر موزوں پراپرٹی ڈھونڈیں گے۔"][i]}</p>
      <div className="reqchips">{pts.map((x, k) => <span key={x[0]} className="reqchip" style={{ "--n": k }}><Icon name="check" size={14} />{x[i]}</span>)}</div>
      <a className="btn reqbtn" href={L("#/buy-request")}><span>{["Tell us your requirement ›", "अपनी ज़रूरत बताइए ›", "اپنی ضرورت بتائیے ›"][i]}</span></a>
    </section>
  );
}
