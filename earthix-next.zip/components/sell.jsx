"use client";

import React, { useState, useEffect, useLayoutEffect, useRef, useCallback, useMemo, useContext, createContext, startTransition, useId } from "react";
import { L3, tr } from "@/lib/i18n";
import { useLang } from "@/lib/lang";
import { DOCS, DOC_NOTE, SELL_PHOTO_AUTOSHRINK, SELL_PHOTO_KB, SELL_PHOTO_LIMIT, SELL_PHOTO_MAX, dataUrlBytes, ex, fmtKB, hint, missingDetails, readDataUrl, scrollToError, shrinkUnderLimit } from "@/lib/forms";
import { safeUrl } from "@/lib/media";
import { MOBILE_RE, UNITS, cleanMobile, fmtINR, fmtNum, fromSqft, makeId, pricePerKatha, toSqft } from "@/lib/helpers";
import { acctEmail, getDb, saveDb } from "@/lib/store";
import { QUEUED_MSG, REMOTE, reqPayload, submitRemote } from "@/lib/backend";
import { scrollTopNow, L } from "@/lib/nav";
import { Err, Field, PageHead, WhatsAppIcon } from "@/components/common";
import { CATEGORIES, waLink } from "@/lib/config";
import { waText } from "@/lib/content";
import { DetailFields, FormShell, LocationPicker, SearchSelect, StepHead } from "@/components/forms";


export function PhotoPicker({ photos, onChange }) {
  const { lang } = useLang();
  const [busy, setBusy] = useState(false), [log, setLog] = useState([]), [drag, setDrag] = useState(false);
  const full = photos.length >= SELL_PHOTO_MAX;
  const handle = async (list) => {
    const files = Array.from(list || []);
    if (!files.length || busy) return;
    setBusy(true); setLog([]);
    const out = [], msgs = [];
    let room = SELL_PHOTO_MAX - photos.length;
    for (const file of files) {
      const nm = file.name || "photo";
      if (!/^image\//i.test(file.type) && !/\.(jpe?g|png|webp|gif|bmp)$/i.test(nm)) { msgs.push({ ok: false, t: nm + ": not an image file." }); continue; }
      if (room <= 0) { msgs.push({ ok: false, t: nm + ": skipped, maximum " + SELL_PHOTO_MAX + " photos." }); continue; }
      try {
        let u;
        if (file.size < SELL_PHOTO_LIMIT) u = await readDataUrl(file);
        else if (SELL_PHOTO_AUTOSHRINK) u = await shrinkUnderLimit(file);
        else { msgs.push({ ok: false, t: nm + " is " + fmtKB(file.size) + ". Each photo must be under " + SELL_PHOTO_KB + " KB, so it was not added." }); continue; }
        if (!u || dataUrlBytes(u) >= SELL_PHOTO_LIMIT) { msgs.push({ ok: false, t: nm + " could not be made smaller than " + SELL_PHOTO_KB + " KB, so it was not added." }); continue; }
        out.push(u); room--;
        msgs.push({ ok: true, t: nm + " added (" + fmtKB(dataUrlBytes(u)) + (file.size >= SELL_PHOTO_LIMIT ? ", shrunk from " + fmtKB(file.size) : "") + ")" });
      } catch (e) { msgs.push({ ok: false, t: nm + " could not be read. Try a JPG or PNG." }); }
    }
    setBusy(false); setLog(msgs);
    if (out.length) onChange(photos.concat(out).slice(0, SELL_PHOTO_MAX));
  };
  const pick = (e) => { const fl = e.target.files; handle(fl).then(() => { try { e.target.value = ""; } catch (x) { /* ignore */ } }); };
  const slots = [];
  for (let k = 0; k < SELL_PHOTO_MAX; k++) {
    if (photos[k]) slots.push(<div key={k} className="ph-item"><img src={photos[k]} alt={"Photo " + (k + 1)} />{k === 0 && <span className="ph-cover" title={L3(lang, "Cover photo", "मुख्य फ़ोटो", "اہم تصویر")} aria-label={L3(lang, "Cover photo", "मुख्य फ़ोटो", "اہم تصویر")}>★</span>}<span className="ph-kb" dir="ltr">{fmtKB(dataUrlBytes(photos[k]))}</span><button type="button" className="ph-x" aria-label={"Remove photo " + (k + 1)} onClick={() => { setLog([]); onChange(photos.filter((_, j) => j !== k)); }}>×</button></div>);
    else slots.push(<div key={k} className="ph-slot" aria-hidden="true">{k + 1}</div>);
  }
  return (
    <div className="fld" id="s-photos-box">
      <div className="lbl">{L3(lang, "Property photos (optional, max " + SELL_PHOTO_MAX + ")", "प्रॉपर्टी की फ़ोटो (वैकल्पिक, अधिकतम " + SELL_PHOTO_MAX + ")", "پراپرٹی کی تصاویر (اختیاری، زیادہ سے زیادہ " + SELL_PHOTO_MAX + ")")}</div>
      <div className="hint">{L3(lang, "Each photo is made smaller than " + SELL_PHOTO_KB + " KB automatically. A photo that cannot be made that small is not added.", "हर फ़ोटो अपने-आप " + SELL_PHOTO_KB + " KB से छोटी कर दी जाती है। जो फ़ोटो इतनी छोटी न हो सके, वह नहीं जुड़ेगी।", "ہر تصویر خود بخود " + SELL_PHOTO_KB + " KB سے چھوٹی کر دی جاتی ہے۔ جو تصویر اتنی چھوٹی نہ ہو سکے وہ شامل نہیں ہوگی۔")}</div>
      <div className={"ph-zone" + (drag ? " drag" : "")} onDragOver={(e) => { e.preventDefault(); if (!full) setDrag(true); }} onDragLeave={() => setDrag(false)} onDrop={(e) => { e.preventDefault(); setDrag(false); if (!full) handle(e.dataTransfer && e.dataTransfer.files); }}>
        <div className="ph-grid">{slots}</div>
        <div className="ph-actions">
          <label className={"ph-btn main" + (full || busy ? " off" : "")}>🖼️ {L3(lang, "Choose from gallery", "गैलरी से चुनें", "گیلری سے چنیں")}<input id="s-photos" type="file" accept="image/*" multiple hidden disabled={full || busy} onChange={pick} /></label>
          <label className={"ph-btn" + (full || busy ? " off" : "")}>📷 {L3(lang, "Take a photo", "फ़ोटो खींचें", "تصویر کھینچیں")}<input id="s-photos-cam" type="file" accept="image/*" capture="environment" hidden disabled={full || busy} onChange={pick} /></label>
        </div>
        <p className="ph-count" dir="ltr" role="status">{busy ? L3(lang, "Preparing photos…", "फ़ोटो तैयार हो रही हैं…", "تصاویر تیار ہو رہی ہیں…") : full ? L3(lang, "Maximum " + SELL_PHOTO_MAX + " photos added", "अधिकतम " + SELL_PHOTO_MAX + " फ़ोटो जुड़ गईं", "زیادہ سے زیادہ " + SELL_PHOTO_MAX + " تصاویر شامل ہو گئیں") : photos.length + " / " + SELL_PHOTO_MAX}</p>
        {log.length > 0 && <ul className="ph-log" aria-live="polite">{log.map((m, i) => <li key={i} className={m.ok ? "ok" : "no"}><b>{m.ok ? "✓" : "✕"}</b><span>{m.t}</span></li>)}</ul>}
      </div>
    </div>
  );
}

export function SellPage({ settings, toast }) {
  const { lang, t } = useLang();
  const [step, setStep] = useState(0);
  const [f, setF] = useState({ category: "", details: {}, mapLink: "", mediaLink: "", photos: [], district: "", block: "", panchayat: "", village: "", area: "", unit: "Katha", price: "", name: "", mobile: "", notes: "", consent: false });
  const [err, setErr] = useState({});
  const [dup, setDup] = useState(false);
  const firstRun = useRef(true);
  const [done, setDone] = useState(null);
  const [busy, setBusy] = useState(false);
  const up = (k) => (e) => { setDup(false); setF((s) => ({ ...s, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value })); };
  const validate = (s) => {
    const er = {};
    if (s === 0 && !f.category) er.category = "Choose a category.";
    if (s === 1) { if (!f.district) er.district = "Choose a district."; if (!f.block) er.block = "Choose a block / anchal."; if (!f.panchayat.trim()) er.panchayat = "Choose or type the panchayat / halka."; if (!f.village.trim()) er.village = "Choose or type the village / mauja."; }
    if (s === 2 && !(Number(f.area) > 0)) er.area = "Enter the area as a number above 0.";
    if (s === 3) Object.assign(er, missingDetails("sell", f.category, f.details));
    if (s === 4 && !(Number(f.price) > 0)) er.price = "Enter your expected price in rupees.";
    if (s === 5) { if (f.mapLink.trim() && !safeUrl(f.mapLink)) er.mapLink = "Paste the full link starting with https://"; if (f.mediaLink.trim() && !safeUrl(f.mediaLink)) er.mediaLink = "Paste the full link starting with https://"; if (f.name.trim().length < 2) er.name = "Enter your name."; if (!MOBILE_RE.test(f.mobile)) er.mobile = "Enter a valid 10-digit mobile number."; if (!f.consent) er.consent = "Please accept to continue."; }
    return er;
  };
  const next = () => { const er = validate(step); setErr(er); if (!Object.keys(er).length) setStep(step + 1); else setTimeout(scrollToError, 40); };
  const submit = (e) => {
    e.preventDefault();
    const er = validate(5); setErr(er);
    if (Object.keys(er).length) { setTimeout(scrollToError, 40); return; }
    const db = getDb();
    const isDup = (db.requests || []).some((r) => r.mobile === f.mobile && r.category === f.category && r.block === f.block && (r.district || "") === f.district && (r.panchayat || "") === f.panchayat.trim() && (r.village || "") === f.village.trim());
    if (isDup && !dup) { setDup(true); return; }
    const req = { id: makeId("REQ"), type: "sell", acct: acctEmail(), category: f.category, details: f.details, mapLink: f.mapLink.trim(), mediaLink: f.mediaLink.trim(), photos: f.photos.slice(0, SELL_PHOTO_MAX), district: f.district, block: f.block, panchayat: f.panchayat.trim(), village: f.village.trim(), locality: f.village.trim() || f.panchayat.trim(), area: Number(f.area), unit: f.unit, price: Number(f.price), name: f.name.trim(), mobile: f.mobile, notes: f.notes, status: 0, at: Date.now() };
    const finish = () => { db.requests = (db.requests || []).concat(req); if (!saveDb(db).ok) { toast(t("storageFull")); return; } setDone(req); };
    if (!REMOTE) { finish(); return; }
    setBusy(true);
    submitRemote("submit_request", { p_data: reqPayload(req) }).then((res) => { setBusy(false); if (!res.ok) { toast(res.error); return; } finish(); if (res.queued) toast(QUEUED_MSG); });
  };
  useEffect(() => { if (done) scrollTopNow(); }, [done]);
  const stepRef = useRef(true);
  useEffect(() => { if (stepRef.current) { stepRef.current = false; return; } const el = document.getElementById("form-top"); if (el && el.scrollIntoView) el.scrollIntoView({ block: "start" }); }, [step]);
  const sq = toSqft(f.area, f.unit, settings.sqftPerKatha);
  const ppk = pricePerKatha(f.price, f.area, f.unit, settings.sqftPerKatha);
  const isRent = f.category === "rental" || (f.details || {}).listFor === "For rent";
  if (done) {
    return (
      <div className="wrap" style={{ maxWidth: 560, paddingBottom: 48 }}>
        <PageHead pill="Sell" plain="Request " hl="received." />
        <div className="card">
          <p className="cb"><b>{tr("Request ID:")}</b> <span dir="ltr">{done.id}</span></p>
          <b style={{ color: "var(--ink)" }}>{tr("Documents to bring to your meeting")}</b>
          <ul style={{ paddingInlineStart: 18, fontSize: 14 }}>{((settings.docLists && settings.docLists.sell) || DOCS.sell).map((d) => <li key={d}>{d}</li>)}</ul>
          <p style={{ fontSize: 12.5 }}>{DOC_NOTE}</p>
          <div className="stack">
            <a className="btn btn-wa" href={L(waLink(settings.whatsapp, waText("sell", done, lang)))} target="_blank" rel="noopener noreferrer"><WhatsAppIcon size={18} />{tr("Confirm on WhatsApp")}</a>
            <a className="btn btn-outline" href={L("#/track")}>{tr("Track my request")}</a>
            <a className="btn btn-outline" href={L("#/")}>{tr("Back to home")}</a>
          </div>
        </div>
      </div>
    );
  }
  return (
    <FormShell kind="sell" step={step}>
      <form className="card formcard sell" onSubmit={submit} noValidate>
        <StepHead kind="sell" step={step} />
        {step === 0 && <SearchSelect id="s-cat" label={tr("Category")} value={f.category} options={CATEGORIES.map((c) => ({ v: c.slug, l: c.name[0] }))} error={err.category} onChange={(v) => { setDup(false); setF((x) => ({ ...x, category: v, details: x.category === v ? x.details : {} })); }} />}
        {step === 1 && <LocationPicker value={f} errors={err} onChange={(patch) => { setDup(false); setF((x) => ({ ...x, ...patch })); }} />}
        {step === 2 && <div><Field id="s-area" hint={hint("area")} label={tr("Area")} error={err.area}><input id="s-area" placeholder={ex("area")} className="inp" dir="ltr" inputMode="decimal" value={f.area} onChange={up("area")} /></Field><SearchSelect id="s-unit" label={tr("Unit")} value={f.unit} options={UNITS} onChange={(v) => { setDup(false); setF((x) => ({ ...x, unit: v })); }} />{sq ? <p className="cb" style={{ fontSize: 13 }} dir="ltr">= {fmtNum(sq, 0)} Sq ft ≈ {fmtNum(fromSqft(sq, "Katha", settings.sqftPerKatha), 2)} Katha</p> : null}<p style={{ fontSize: 12.5 }}>{t("unitNote")}</p></div>}
        {step === 3 && <DetailFields kind="sell" category={f.category} value={f.details} errors={err} onChange={(dt) => { setDup(false); setF((x) => ({ ...x, details: dt })); }} />}
        {step === 4 && <div><Field id="s-price" hint={hint("price")} label={isRent ? "Expected monthly rent (₹)" : "Expected price (₹)"} error={err.price}><input id="s-price" placeholder={ex("price")} className="inp" dir="ltr" inputMode="numeric" value={f.price} onChange={up("price")} /></Field>{ppk && !isRent ? <p className="cb" style={{ fontSize: 13 }}>≈ {fmtINR(Math.round(ppk))} {t("perKatha")}</p> : null}</div>}
        {step === 5 && <div><Field id="s-name" label={tr("Your name")} error={err.name}><input id="s-name" placeholder={ex("name")} className="inp" autoComplete="name" value={f.name} onChange={up("name")} /></Field><Field id="s-mobile" hint={hint("mobile")} label={tr("Mobile number")} error={err.mobile}><input id="s-mobile" placeholder={ex("mobile")} className="inp" dir="ltr" inputMode="numeric" value={f.mobile} onChange={(e) => { setDup(false); setF((s) => ({ ...s, mobile: cleanMobile(e.target.value) })); }} /></Field><Field id="s-map" label={tr("Google Maps link of the exact place (optional)")} hint={tr("Open the place in Google Maps, tap Share and paste the link.")} error={err.mapLink}><input id="s-map" className="inp" dir="ltr" inputMode="url" placeholder="https://maps.app.goo.gl/..." value={f.mapLink} onChange={up("mapLink")} /></Field><PhotoPicker photos={f.photos} onChange={(arr) => { setDup(false); setF((x) => ({ ...x, photos: arr })); }} /><Field id="s-media" label={tr("Video link (optional)")} hint={tr("YouTube, Google Drive or any public link.")} error={err.mediaLink}><input id="s-media" className="inp" dir="ltr" inputMode="url" placeholder="https://..." value={f.mediaLink} onChange={up("mediaLink")} /></Field><Field id="s-notes" hint={hint("notes")} label={tr("Notes (optional)")}><textarea id="s-notes" placeholder={ex("notes")} className="inp" style={{ height: 80, padding: 12 }} value={f.notes} onChange={up("notes")} /></Field><label className="chk"><input id="s-consent" type="checkbox" checked={f.consent} onChange={up("consent")} /> {tr("I agree to be contacted privately.")}</label><Err m={err.consent} />{dup && <div className="err" role="alert">{tr("A similar request from this number already exists. Press Submit again to send it anyway.")}</div>}</div>}
        <div style={{ display: "flex", gap: 10, marginTop: 18 }}>
          {step > 0 && <button key="back" type="button" className="btn btn-outline" style={{ flex: 1 }} onClick={() => { setErr({}); setStep(step - 1); }}>{tr("Back")}</button>}
          {step < 5 ? <button key="next" type="button" className="btn btn-primary" style={{ flex: 1 }} onClick={next}>{tr("Next ›")}</button> : <button key="submit" type="submit" disabled={busy} className="btn btn-primary" style={{ flex: 1 }}>{tr("Submit")}</button>}
        </div>
      </form>
    </FormShell>
  );
}
