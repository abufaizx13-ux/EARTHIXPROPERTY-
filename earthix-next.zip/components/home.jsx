"use client";

import React, { useState, useEffect, useLayoutEffect, useRef, useCallback, useMemo, useContext, createContext, startTransition, useId } from "react";
import { H, pick, tr, trEn, LANG_NOW } from "@/lib/i18n";
import { useLang } from "@/lib/lang";
import { BRAND, BRAND_TAG, IMG, LANG_IDX } from "@/lib/brand";
import { CountUp, Heading, Icon, PMLogo, SafeImg, Section, SectionHead, WhatsAppIcon, prefersReducedMotion, useRevealOnce, useSwipe } from "@/components/common";
import { HOME_ACTIVE, openInfo } from "@/lib/dom";
import { navigate, L } from "@/lib/nav";
import { CARDS, ECO, ECO_LINK, HERO_CATS, INFO, SH_BUBS, svc, toolLinks, waText } from "@/lib/content";
import { SHAYARI, priceSuffix } from "@/lib/seed";
import { BLOCKS, BLOCKS_FILTER, CATEGORIES, catName, waLink } from "@/lib/config";
import { allProps, getDb } from "@/lib/store";
import { propImages } from "@/lib/media";
import { fmtINR } from "@/lib/helpers";
import { PickBtn, RequirementSection } from "@/components/forms";
import { PropertyCard, VideoSection } from "@/components/property";
import { FounderCard, FraudTips } from "@/components/pages";
import { Newsletter, Reviews } from "@/components/reviews";



// ---------- HERO PHOTO SLIDER ----------
export function HeroSlider({ slides, idxRef }) {
  const { t } = useLang();
  const list = slides && slides.length ? slides : IMG.hero;
  const [i, setI] = useState(0);
  const paused = useRef(false);
  const n = list.length;
  useEffect(() => { if (idxRef) idxRef.current = i; }, [i, idxRef]);
  const go = useCallback((d) => setI((v) => (v + d + n) % n), [n]);
  useEffect(() => {
    if (prefersReducedMotion()) return undefined;
    const id = setInterval(() => { if (!paused.current && HOME_ACTIVE.v && !document.hidden) go(1); }, 4500);
    return () => clearInterval(id);
  }, [go]);
  const sw = useSwipe(() => go(1), () => go(-1));
  const cats = ["farmland", "plots", "roadtouch", "house", "shop"];
  return (
    <div className="slider" onTouchStart={(e) => { paused.current = true; sw.onTouchStart(e); }} onTouchEnd={(e) => { sw.onTouchEnd(e); paused.current = false; }}>
      <div className="track" style={{ transform: "translateX(" + (LANG_NOW.v === "ur" ? i : -i) * 100 + "%)" }}>
        {list.map((src, k) => <div className="slide" key={k}><SafeImg src={src} category={cats[k % 5]} alt={"Saharsa property " + (k + 1)} width={900} height={675} eager={k === 0} /></div>)}
      </div>
      <button type="button" className="arrow l" aria-label={t("prev")} onClick={() => go(-1)}><Icon name="chevL" /></button>
      <button type="button" className="arrow r" aria-label={t("next")} onClick={() => go(1)}><Icon name="chevR" /></button>
      <div className="dots">{list.map((_, k) => <button key={k} type="button" className={k === i ? "on" : ""} aria-label={"Slide " + (k + 1)} aria-pressed={k === i} onClick={() => setI(k)} />)}</div>
    </div>
  );
}


// ---------- HERO (pill, H1, subtitle, buttons, meeting link, gold line, chips, THEN slider) ----------
export function Hero({ settings, onBook }) {
  const { t } = useLang();
  const idx = useRef(0);
  const touch = useRef({ x: 0, moved: false });
  const openHero = (e) => {
    if (touch.current.moved) return;
    const el = e.target && e.target.closest ? e.target : null;
    if (!el || el.closest("a,button,input,select,textarea,label,summary")) return;
    navigate(el.closest(".slider") ? "#/buy/" + HERO_CATS[idx.current % HERO_CATS.length] : "#/buy");
  };
  return (
    <div className="hero-click" role="group" aria-label={t("browse")} tabIndex={0} onClick={openHero}
      onKeyDown={(e) => { if (e.key === "Enter" && e.target === e.currentTarget) navigate("#/buy"); }}
      onTouchStart={(e) => { touch.current = { x: e.touches[0].clientX, moved: false }; }}
      onTouchMove={(e) => { if (Math.abs(e.touches[0].clientX - touch.current.x) > 12) touch.current.moved = true; }}
      onTouchEnd={() => { setTimeout(() => { touch.current.moved = false; }, 350); }}>
      <section className="hero">
        <div className="orbs" aria-hidden="true"><i /><i /><i /></div>
        <span className="pill up">{svc("badge")}</span>
        <Heading id="hero" level={1} />
        <p className="sub">{t("heroSub")}</p>
        <div className="row">
          <a className="btn btn-outline" href={L("#/buy")}>{t("buyProperty")}</a>
          <a className="btn btn-primary" href={L("#/sell")}>{t("sellProperty")} ›</a>
        </div>
        <p style={{ margin: "14px 0 0" }}><button type="button" className="btn btn-link" onClick={onBook}><Icon name="calendar" size={18} />{t("bookMeeting")}</button></p>
        <p className="goldline">{t("heroLine")}</p>
        <p className="svcnote"><span className="dot" aria-hidden="true" /><span>{svc("note")}</span></p>
        <div className="chips">
          {[["lock", "chipPrivate", "Nothing is published"], ["rupee", "chipCommission", "Commission told upfront"], ["shield", "chipVerified", "Admin-verified listings"]].map(([ic, k, key]) => <button type="button" className="chip chipbtn" key={k} aria-haspopup="dialog" onClick={() => openInfo(key)}><b><Icon name={ic} size={16} /></b>{t(k)}</button>)}
        </div>
        <HeroExtras />
      </section>
      <HeroSlider slides={settings.heroSlides} idxRef={idx} />
    </div>
  );
}

export const shWords = (text, base) => String(text || "").split(/\s+/).filter(Boolean).map((w, k) => <React.Fragment key={k}>{k ? " " : null}<span className="sw" style={{ "--d": (base + k * 0.09).toFixed(2) + "s" }}>{w}</span></React.Fragment>);

export function ShayariBand({ settings }) {
  const { lang } = useLang();
  const lines = (settings.shayari && settings.shayari[lang]) || SHAYARI[lang];
  const [i, setI] = useState(0);
  const paused = useRef(false);
  const n = lines.length;
  const go = useCallback((d) => setI((v) => (v + d + n) % n), [n]);
  useEffect(() => { setI(0); }, [lang]);
  useEffect(() => {
    const id = setInterval(() => { if (!paused.current && HOME_ACTIVE.v && !document.hidden) go(1); }, 6000);
    return () => clearInterval(id);
  }, [go]);
  const sw = useSwipe(() => go(1), () => go(-1));
  const pair = lines[i % n];
  return (
    <section className="shayari" aria-label="Shayari" onTouchStart={(e) => { paused.current = true; sw.onTouchStart(e); }} onTouchEnd={(e) => { sw.onTouchEnd(e); paused.current = false; }}>
      <div className="shcard">
        <div className="bubwrap" aria-hidden="true">{SH_BUBS.map((b, k) => <span key={k} className="bub" style={{ "--l": b[0] + "%", "--s": b[1] + "px", "--d": b[2] + "s", "--dl": b[3] + "s" }} />)}</div>
        <span className="shq" aria-hidden="true">“</span><span className="shq r" aria-hidden="true">“</span>
        <div className="orn" aria-hidden="true">✦ ✦ ✦</div>
        <div key={lang + "-" + i} aria-live="polite">
          <p className="l1">{shWords(pair[0], 0)}</p>
          <i className="shdiv" aria-hidden="true" />
          <p className="l2">{shWords(pair[1], 0.35 + String(pair[0]).split(/\s+/).length * 0.09)}</p>
        </div>
        <div className="sig">{"— " + BRAND[LANG_IDX[lang] ?? 0]}</div>
        <div className="orn" aria-hidden="true" style={{ marginTop: 12 }}>✦ ✦ ✦</div>
        <div className="sdots">{lines.map((_, k) => <button key={k} type="button" className={k === i ? "on" : ""} aria-label={"Shayari " + (k + 1)} aria-pressed={k === i} onClick={() => setI(k)} />)}</div>
      </div>
    </section>
  );
}

export function CategoriesSection() {
  const { lang, t } = useLang();
  return (
    <section className="sec" id="sec-categories">
      <div className="wrap">
        <SectionHead pill={t("pillCats")} id="cats" />
        <div className="tiles">
          {CATEGORIES.map((c) => (
            <a key={c.slug} className="ctile" href={L("#/buy/" + c.slug)}>
              <div className="im"><SafeImg src={((getDb().settings.catImages || {})[c.slug]) || IMG.categories[c.slug]} category={c.slug} alt={c.name[LANG_IDX[lang]]} width={600} height={450} /></div>
              <span>{c.name[LANG_IDX[lang]]}</span>
            </a>
          ))}
        </div>
        <div className="stack">
          <a className="btn btn-outline" href={L("#/categories")}>{t("viewAllCats")} ›</a>
          <a className="card" style={{ display: "flex", alignItems: "center", gap: 12, padding: 16 }} href={L("#/sell")}><span className="tile"><Icon name="rupee" /></span><b style={{ color: "var(--ink)" }}>{t("wantSell")} ›</b></a>
        </div>
      </div>
    </section>
  );
}

export function DealStrip({ more }) {
  const { lang, t } = useLang();
  const li = LANG_IDX[lang] ?? 0;
  const L = (en, hi, ur) => [en, hi, ur][li];
  const rowRef = useRef(null);
  const paused = useRef(false);
  const [page, setPage] = useState(0);
  const [per, setPer] = useState(2);
  const [boxRef, seen] = useRevealOnce(0.15);
  const sale = allProps().filter((p) => p.listingType !== "rent");
  const flagged = sale.filter((p) => p.featured);
  const rest = sale.filter((p) => !p.featured);
  const list = flagged.concat(rest).slice(0, Math.min(12, Math.max(6, flagged.length)));
  const pages = Math.max(1, Math.ceil(list.length / per));
  useEffect(() => {
    const calc = () => setPer(window.innerWidth >= 1000 ? 5 : window.innerWidth >= 640 ? 3 : 2);
    calc();
    window.addEventListener("resize", calc);
    return () => window.removeEventListener("resize", calc);
  }, []);
  const dirSign = () => (LANG_NOW.v === "ur" ? -1 : 1);
  const pageW = () => { const el = rowRef.current; return el ? el.clientWidth + 10 : 0; };
  const goTo = useCallback((p) => {
    const el = rowRef.current;
    if (!el) return;
    el.scrollTo({ left: dirSign() * p * pageW(), behavior: prefersReducedMotion() ? "auto" : "smooth" });
  }, []);
  const onScroll = () => {
    const el = rowRef.current;
    if (!el) return;
    const w = pageW();
    if (w) setPage(Math.min(pages - 1, Math.max(0, Math.round(Math.abs(el.scrollLeft) / w))));
  };
  useEffect(() => {
    if (pages < 2 || prefersReducedMotion() || !seen) return undefined;
    const id = setInterval(() => { if (!paused.current && !document.hidden) { const el = rowRef.current; const w = pageW(); const cur = el && w ? Math.round(Math.abs(el.scrollLeft) / w) : 0; goTo((cur + 1) % pages); } }, 4200);
    return () => clearInterval(id);
  }, [pages, seen, goTo]);
  if (!list.length) return null;
  const hold = () => { paused.current = true; };
  const free = () => { setTimeout(() => { paused.current = false; }, 2500); };
  const title = more ? L("More picks for you", "आपके लिए और विकल्प", "آپ کے لیے مزید انتخاب") : L("Top picks for buyers", "खरीदारों के लिए खास चुनाव", "خریداروں کے لیے خاص انتخاب");
  return (
    <section ref={boxRef} className={"ds" + (seen ? " seen" : "")} aria-label={title}>
      <div className="ds-head">
        <h3><span className="ds-bar" aria-hidden="true" />{title}</h3>
        <a href={L("#/buy")} className="ds-all">{L("View all", "सभी देखें", "سب دیکھیں")} ›</a>
      </div>
      <div className="ds-wrap" onMouseEnter={hold} onMouseLeave={free} onTouchStart={hold} onTouchEnd={free} onFocus={hold} onBlur={free}>
        {pages > 1 && <button type="button" className="ds-arrow prev" aria-label={L("Previous", "पिछला", "پچھلا")} onClick={() => goTo((page - 1 + pages) % pages)}>‹</button>}
        <div className="ds-row" ref={rowRef} onScroll={onScroll} role="list">
          {list.map((p, k) => {
            const title2 = pick(p.title, lang);
            const img = propImages(p)[0] || "";
            return (
              <a key={p.id} role="listitem" className="dcard" style={{ "--k": k }} href={L("#/property/" + p.id)} aria-label={title2}>
                <div className="dim">
                  <SafeImg src={img} category={p.category} alt={title2} width={480} height={360} />
                  <span className="dcat">{catName(p.category, lang)}</span>
                  {p.verified && <span className="dver"><Icon name="shield" size={11} />{t("verified")}</span>}
                </div>
                <div className="dbody">
                  <div className="dtitle">{title2}</div>
                  <div className="dprice">{fmtINR(p.price)}<small>{priceSuffix(p) ? t("perMonth") : ""}</small></div>
                  <div className="dloc"><Icon name="pin" size={12} />{p.locality}, {p.block}</div>
                  {p.area ? <div className="darea">{p.area} {p.unit}</div> : null}
                </div>
              </a>
            );
          })}
        </div>
        {pages > 1 && <button type="button" className="ds-arrow next" aria-label={L("Next", "अगला", "اگلا")} onClick={() => goTo((page + 1) % pages)}>›</button>}
      </div>
      {pages > 1 && <div className="ds-dots" role="tablist">{Array.from({ length: pages }).map((_, k) => <button key={k} type="button" role="tab" aria-selected={k === page} aria-label={(k + 1) + " / " + pages} className={k === page ? "on" : ""} onClick={() => goTo(k)} />)}</div>}
    </section>
  );
}

export function HeroExtras() {
  const { lang } = useLang();
  const li = LANG_IDX[lang] ?? 0;
  const L = (en, hi, ur) => [en, hi, ur || en][li];
  const [cat, setCat] = useState(""), [blk, setBlk] = useState("");
  const props = allProps();
  const go = (e) => { e.preventDefault(); navigate("#/buy" + (cat ? "/" + cat : "") + (blk ? "?block=" + encodeURIComponent(blk) : "")); };
  const stats = [
    [props.length, L("Showcase listings", "शोकेस लिस्टिंग", "شو کیس لسٹنگ"), "#/buy", "home"],
    [props.filter((p) => p.verified).length, L("Admin-verified", "एडमिन-सत्यापित", "ایڈمن سے تصدیق شدہ"), "#/buy?verified=1", "shield"],
    [CATEGORIES.length, L("Property types", "प्रॉपर्टी के प्रकार", "پراپرٹی کی اقسام"), "#/categories", "layers"],
    [BLOCKS.length, L("Blocks covered", "ब्लॉक कवर", "بلاک"), "#/buy", "pin"],
  ];
  return (
    <div className="hx" onClick={(e) => e.stopPropagation()}>
      <DealStrip />
      <form className="hsearch" onSubmit={go} aria-label={L("Find a property", "प्रॉपर्टी खोजें", "پراپرٹی تلاش کریں")}>
        <b className="hs-t">{L("Find your property", "अपनी प्रॉपर्टी खोजें", "اپنی پراپرٹی تلاش کریں")}</b>
        <div className="hs-row">
          <label><span>{L("Type", "प्रकार", "قسم")}</span><PickBtn className="hs-pick" title={L("Type", "प्रकार", "قسم")} value={cat} onChange={setCat} options={[{ v: "", l: L("All categories", "सभी श्रेणियाँ", "تمام اقسام") }].concat(CATEGORIES.map((c) => ({ v: c.slug, l: c.name[li] })))} /></label>
          <label><span>{L("Block", "ब्लॉक", "بلاک")}</span><PickBtn className="hs-pick" title={L("Block", "ब्लॉक", "بلاک")} value={blk} onChange={setBlk} options={[{ v: "", l: L("All blocks", "सभी ब्लॉक", "تمام بلاکس") }].concat(BLOCKS_FILTER.map((b) => ({ v: b, l: b })))} /></label>
          <button type="submit" className="btn btn-primary">{L("Search", "खोजें", "تلاش")} ›</button>
        </div>
      </form>
      <div className="hstats">{stats.map(([n, l, href, ic], k) => <a key={l} href={L(href)} className="hstat" style={{ "--k": k }}><span className="hs-ic"><Icon name={ic} size={20} /></span><span className="hs-tx"><b><CountUp to={n} />{n > 0 ? "+" : ""}</b><span>{l}</span></span></a>)}</div>
    </div>
  );
}

export function CardsSection({ alt, pillKey, id, subKey, items, links, numbered, extra }) {
  const { lang, t } = useLang();
  return (
    <Section alt={alt} id={"sec-" + id}>
      <SectionHead pill={t(pillKey)} id={id === "safe" ? "safety" : id} sub={t(subKey)} />
      <div className="grid">
        {items.map(([ic, title, body], k) => {
          const Wrap = links ? "a" : "div";
          const more = !links && INFO[title];
          const tap = more ? { role: "button", tabIndex: 0, "aria-haspopup": "dialog", onClick: () => openInfo(title), onKeyDown: (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openInfo(title); } } } : {};
          return (
            <Wrap key={title} className={"card" + (more ? " tapcard" : "")} href={L(links ? links[k] : undefined)} style={{ position: "relative" }} {...tap}>
              {numbered && <span className="big" aria-hidden="true">{k + 1}</span>}
              <span className="tile"><Icon name={ic} size={22} /></span>
              <h3 className="ct">{trEn(title, lang)}</h3><p className="cb">{trEn(body, lang)}</p>
              {links && <b style={{ color: "var(--teal)" }}>{t("open")} ›</b>}
              {more && <b className="more">{lang === "hi" ? "और जानें" : "Learn more"}<i className="arr" aria-hidden="true">›</i></b>}
            </Wrap>
          );
        })}
      </div>
      {extra}
    </Section>
  );
}

export function Ecosystem() {
  const { lang, t } = useLang();
  return (
    <Section alt id="sec-eco">
      <SectionHead pill={t("pillEco")} id="eco" sub={t("subEco")} />
      <div className="flow">
        <div className="eco-top"><b style={{ fontSize: 24, color: "var(--ink)" }}>{BRAND[LANG_IDX[lang] ?? 0]}</b><div>{trEn("Private Property Matchmaking Platform", lang)}</div></div>
        {ECO.map(([ic, name, col, href, bl]) => (
          <React.Fragment key={name}>
            <i className="conn" />
            <div className="eco-card">
              <span className="tile ecoicon"><Icon name={ic} size={26} /></span>
              <h3 style={{ font: "800 24px/1.25 var(--display)", letterSpacing: "-.01em", color: "var(--ink)", margin: "18px 0 10px" }}>{trEn(name, lang)}</h3>
              {bl.map((b) => <a key={b} href={L(ECO_LINK[b] || href)} className="bul bullink"><span style={{ color: col }}><Icon name="check" size={18} /></span>{trEn(b, lang)}</a>)}
              <a href={L(href)} className="btn ecobtn"><span>{t("explore")}</span><i className="arr" aria-hidden="true">→</i></a>
            </div>
          </React.Fragment>
        ))}
      </div>
      <div className="card ecocta" style={{ width: "92%", margin: "32px auto 0", borderRadius: 22, padding: 22 }}>
        <div style={{ display: "flex", gap: 14 }}><span className="tile" style={{ width: 56, height: 56, borderRadius: 16, background: "var(--mint-strong)", flex: "none" }}><Icon name="users" size={26} /></span><div><b style={{ color: "var(--ink)", fontSize: 20 }}>{trEn("Don't see your category?", lang)}</b><p>{trEn("Tell us what you are looking for. If it exists in Saharsa district, we will try to find it privately for you.", lang)}</p></div></div>
        <div className="stack"><a className="btn btn-primary" href={L("#/categories")}>{trEn("Explore All Categories →", lang)}</a><a className="btn btn-wa" href={L(waLink(getDb().settings.whatsapp, waText("category", {}, lang)))} target="_blank" rel="noopener noreferrer"><WhatsAppIcon size={18} />{t("askWa")}</a></div>
      </div>
    </Section>
  );
}

export function Showcase({ saved, toggle }) {
  const { t } = useLang();
  return (
    <section className="sec alt" id="sec-showcase">
      <div className="wrap"><SectionHead pill={t("pillShow")} id="showcase" sub={t("subShow")} /></div>
      <div className="scroller">{allProps().map((p) => <PropertyCard key={p.id} p={p} saved={saved.includes(p.id)} onToggleSave={toggle} />)}</div>
      <div className="wrap" style={{ marginTop: 12 }}><a className="btn btn-outline" style={{ width: "100%" }} href={L("#/buy")}>{t("browse")}</a></div>
    </section>
  );
}

export function CtaBand({ onBook }) {
  const { t } = useLang();
  return (
    <section style={{ background: "var(--grad)", padding: "56px 20px", textAlign: "center", color: "#fff" }}>
      <h2 className="h2" style={{ color: "#fff" }}>{H.cta[LANG_IDX[useLang().lang]][0]}</h2>
      <p style={{ margin: "14px auto 22px", maxWidth: 330 }}>{t("ctaSub")}</p>
      <div style={{ display: "flex", gap: 10, justifyContent: "center", flexWrap: "wrap" }}>
        <a className="btn" style={{ background: "#fff", color: "var(--teal-dark)" }} href={L("#/buy")}>{t("navBuy")}</a>
        <a className="btn" style={{ background: "#fff", color: "var(--teal-dark)" }} href={L("#/sell")}>{t("navSell")}</a>
        <button type="button" className="btn" style={{ background: "var(--gold)", color: "#fff" }} onClick={onBook}>{t("bookMeeting")}</button>
      </div>
    </section>
  );
}

export function WelcomeCard({ onBook }) {
  const { lang } = useLang();
  const li = LANG_IDX[lang] ?? 0;
  const L = (en, hi, ur) => [en, hi, ur][li];
  const [show, setShow] = useState(false);
  const [out, setOut] = useState(false);
  // Shows on every visit: within 1 second of the page opening, whether or not cookies were accepted.
  useEffect(() => {
    const id = setTimeout(() => setShow(true), 300);
    return () => clearTimeout(id);
  }, []);
  const close = useCallback(() => {
    setOut(true);
    setTimeout(() => { setShow(false); setOut(false); }, prefersReducedMotion() ? 0 : 480);
  }, []);
  // Closes by itself after 4.9 seconds (same moment the progress bar runs out), with a smooth slide-out.
  useEffect(() => {
    if (!show) return undefined;
    const id = setTimeout(close, 4900);
    const onKey = (e) => { if (e.key === "Escape") close(); };
    window.addEventListener("keydown", onKey);
    return () => { clearTimeout(id); window.removeEventListener("keydown", onKey); };
  }, [show, close]);
  if (!show) return null;
  const title = tr("Welcome to Earthix Property");
  const brandWords = String(BRAND[li]).split(/\s+/);
  const words = String(title).split(/\s+/).filter(Boolean);
  const chips = [
    ["calendar", L("Free meeting", "मुफ़्त मीटिंग", "مفت ملاقات")],
    ["lock", L("100% private", "100% निजी", "100٪ نجی")],
    ["clock", L("Mon–Sat, 10–6", "सोम–शनि, 10–6", "پیر تا ہفتہ، 10–6")],
  ];
  return (
    <div className={"welcome wc" + (out ? " out" : "")} role="dialog" aria-label={tr("Welcome")}>
      <span className="wc-bar" aria-hidden="true" />
      <button type="button" className="burger" style={{ position: "absolute", top: 3, insetInlineEnd: 3, width: 34, height: 34 }} aria-label={tr("Close")} onClick={close}><Icon name="close" size={15} /></button>
      <div className="wc-head">
        <span className="wc-logo"><PMLogo size={33} uid="wc" /></span>
        <span className="wc-tag">{BRAND_TAG[li]}</span>
      </div>
      <h2 className="wc-title" aria-label={title}>
        {words.map((w, k) => <span key={k} className={"wc-w" + (brandWords.includes(w) ? " hl" : "")} style={{ "--i": k }} aria-hidden="true">{w}</span>)}
      </h2>
      <p className="wc-sub">{tr("Private property help in Saharsa. Your details are never published.")}</p>
      <ul className="wc-chips">
        {chips.map(([ic, tx], k) => <li key={ic} style={{ "--i": k }}><Icon name={ic} size={12} />{tx}</li>)}
      </ul>
      <button type="button" className="btn btn-primary wc-cta" onClick={() => { close(); onBook(); }}>
        <span>{tr("Book a free meeting")}</span><span className="wc-arr"><Icon name="arrow" size={15} /></span>
      </button>
      <button type="button" className="wc-later" onClick={close}>{L("Maybe later", "बाद में", "بعد میں")}</button>
      <span className="wc-timer" aria-hidden="true" />
    </div>
  );
}

export function Home({ settings, saved, toggle, onBook, toast }) {
  const { t } = useLang();
  // Hero, shayari, the two forms and categories paint first. Everything further down renders right after.
  const [more, setMore] = useState(false);
  useEffect(() => {
    const ric = window.requestIdleCallback;
    const id = ric ? ric(() => setMore(true), { timeout: 500 }) : setTimeout(() => setMore(true), 30);
    return () => { if (ric) { if (window.cancelIdleCallback) window.cancelIdleCallback(id); } else clearTimeout(id); };
  }, []);
  return (
    <div>
      <Hero settings={settings} onBook={onBook} />
      <ShayariBand settings={settings} />
      <RequirementSection />
      <CategoriesSection />
      {more && <>
      <Ecosystem />
      <CardsSection pillKey="pillWhy" id="why" subKey="subWhy" items={CARDS.why} />
      <Showcase saved={saved} toggle={toggle} />
      <CardsSection pillKey="pillHow" id="how" subKey="subHow" items={CARDS.how} numbered />
      <CardsSection alt pillKey="pillSafe" id="safe" subKey="subSafe" items={CARDS.safe} extra={<FraudTips />} />
      <Section id="sec-areas"><SectionHead pill={t("pillAreas")} id="areas" sub={svc("note")} /><div className="chiprow">{BLOCKS_FILTER.map((b) => <a key={b} className="areachip" href={L("#/buy?block=" + encodeURIComponent(b))}>{b}</a>)}</div></Section>
      <CardsSection alt pillKey="pillTools" id="tools" subKey="subTools" items={CARDS.tools} links={toolLinks} />
      <VideoSection url={settings.demoYoutubeUrl} />
      <Section id="sec-founder"><FounderCard settings={settings} /></Section>
      <Section id="sec-deals2"><DealStrip more /></Section>
      <Reviews />
      <WelcomeCard onBook={onBook} />
      <Newsletter toast={toast} />
      <CtaBand onBook={onBook} />
      </>}
    </div>
  );
}
