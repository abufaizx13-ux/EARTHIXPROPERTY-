"use client";

import React, { useState, useEffect, useLayoutEffect, useRef, useCallback, useMemo, useContext, createContext, startTransition, useId } from "react";
import { L } from "@/lib/nav";
import { svc } from "@/lib/content";
import { MOBILE_RE, cleanMobile, fmtINR, ymdLocal } from "@/lib/helpers";
import { WHATSAPP_NUMBER, catName, waLink } from "@/lib/config";
import { Err, Field, Icon, PageHead, WhatsAppIcon } from "@/components/common";
import { STAGES, detailLines } from "@/lib/forms";
import { getDb, importBackup, saveDb, settings0 } from "@/lib/store";
import { T } from "@/lib/i18n";
import { REMOTE, adminPatch, debounced, loadAdminData, pushPublicChanges, sbAdminLogin, sbLogout } from "@/lib/backend";
import { ADMIN, ADM_TAB_ICON, fmtAt, stageCls, toCsv } from "@/lib/admin-lib";
import { SEED_PROPERTIES } from "@/lib/seed";
import { BRAND } from "@/lib/brand";
import { safeUrl } from "@/lib/media";
import { PickBtn } from "@/components/forms";
import { AdminProps } from "@/components/admin/AdminProps";
import { AdminBrand, AdminContent, AdminFounder, AdminLocations, AdminReviews } from "@/components/admin/AdminSite";


export function SettingsForm({ settings, onSave }) {
  const [f, setF] = useState({ whatsapp: settings.whatsapp, phones: settings.phones.join(", "), hours: settings.hours[0], hoursHi: settings.hours[1], hoursUr: settings.hours[2], address: settings.address[0], addressHi: settings.address[1], addressUr: settings.address[2], email: settings.email, map: settings.map, sqftPerKatha: settings.sqftPerKatha, commission: settings.commission, demoYoutubeUrl: settings.demoYoutubeUrl || "", facebook: settings.socials.facebook || "", instagram: settings.socials.instagram || "", youtube: settings.socials.youtube || "", sbEn: svc("badge", "en"), sbHi: svc("badge", "hi"), sbUr: svc("badge", "ur"), snEn: svc("note", "en"), snHi: svc("note", "hi"), snUr: svc("note", "ur") });
  const set = (k) => (e) => setF((s) => ({ ...s, [k]: e.target.value }));
  const save = (e) => {
    e.preventDefault();
    const phones = f.phones.split(",").map((x) => x.trim()).filter((x) => MOBILE_RE.test(x));
    if (!phones.length) { onSave(null, "Enter at least one valid 10-digit phone."); return; }
    if (!(Number(f.sqftPerKatha) > 0)) { onSave(null, "Sq ft per Katha must be above 0."); return; }
    onSave({ whatsapp: f.whatsapp.replace(/\D/g, "") || WHATSAPP_NUMBER, phones, hours: [f.hours.trim(), f.hoursHi.trim() || f.hours.trim(), f.hoursUr.trim() || f.hours.trim()], address: [f.address.trim(), f.addressHi.trim() || f.address.trim(), f.addressUr.trim() || f.address.trim()], email: f.email, map: f.map, sqftPerKatha: Number(f.sqftPerKatha), commission: Number(f.commission), demoYoutubeUrl: f.demoYoutubeUrl, socials: { whatsapp: waLink(f.whatsapp.replace(/\D/g, "") || WHATSAPP_NUMBER), facebook: f.facebook, instagram: f.instagram, youtube: f.youtube }, service: { badge: [f.sbEn.trim(), f.sbHi.trim(), f.sbUr.trim()], note: [f.snEn.trim(), f.snHi.trim(), f.snUr.trim()] } });
  };
  const F = (k, label, extra) => <Field id={"st-" + k} label={label}><input id={"st-" + k} className="inp" value={f[k]} onChange={set(k)} {...(extra || {})} /></Field>;
  return (
    <form className="card" onSubmit={save} noValidate>
      {F("whatsapp", "WhatsApp number (with 91)", { dir: "ltr" })}{F("phones", "Phones (comma separated)", { dir: "ltr" })}{F("hours", "Hours (English)")}{F("hoursHi", "Hours (Hindi)")}{F("hoursUr", "Hours (Urdu)", { dir: "rtl" })}{F("address", "Address (English)")}{F("addressHi", "Address (Hindi)")}{F("addressUr", "Address (Urdu)", { dir: "rtl" })}{F("email", "Email", { dir: "ltr" })}{F("map", "Map link", { dir: "ltr" })}
      {F("sqftPerKatha", "Sq ft per Katha (confirm with local amin)", { inputMode: "decimal", dir: "ltr" })}{F("commission", "Commission %", { inputMode: "decimal", dir: "ltr" })}{F("demoYoutubeUrl", "Demo YouTube URL", { dir: "ltr" })}{F("facebook", "Facebook URL", { dir: "ltr" })}{F("instagram", "Instagram URL", { dir: "ltr" })}{F("youtube", "YouTube URL", { dir: "ltr" })}
      <h3 className="ct" style={{ marginBottom: 4 }}>Service area message</h3>
      <p className="hint">Shown on the Home hero, Areas We Serve, FAQ and footer. Change it when you open a new district or state.</p>
      {[["sbEn", "Short badge (English)", false], ["sbHi", "Short badge (Hindi)", false], ["sbUr", "Short badge (Urdu)", false], ["snEn", "Message (English)", true], ["snHi", "Message (Hindi)", true], ["snUr", "Message (Urdu)", true]].map(([k, l, long]) => <Field key={k} id={"st-" + k} label={l}>{long ? <textarea id={"st-" + k} className="inp" style={{ height: 96, padding: 12 }} maxLength={260} value={f[k]} onChange={set(k)} /> : <input id={"st-" + k} className="inp" maxLength={48} value={f[k]} onChange={set(k)} />}</Field>)}
      <button type="submit" className="btn btn-primary" style={{ width: "100%", marginTop: 14 }}>Save settings</button>
    </form>
  );
}

// ---------- ADMIN DASHBOARD HELPERS ----------
export function AdminCountUp({ to }) {
  const [v, setV] = useState(0);
  useEffect(() => {
    const n = Number(to) || 0; let raf = 0, t0 = 0;
    const step = (t) => { if (!t0) t0 = t; const p = Math.min(1, (t - t0) / 700); setV(Math.round(n * (1 - Math.pow(1 - p, 3)))); if (p < 1) raf = requestAnimationFrame(step); };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [to]);
  return <>{v}</>;
}

export function AdmEmpty({ icon, text }) {
  return <div className="adm-empty"><span className="tile adm-tile"><Icon name={icon} size={24} /></span><p>{text}</p></div>;
}

export function AdmContact({ mobile, msg }) {
  if (!mobile) return null;
  return (
    <div className="adm-act">
      <a className="btn btn-wa" href={L(waLink("91" + mobile, msg))} target="_blank" rel="noopener noreferrer"><WhatsAppIcon size={16} />WhatsApp</a>
      <a className="btn btn-outline" href={L("tel:+91" + mobile)}><Icon name="phone" size={16} />Call</a>
    </div>
  );
}

export function AdmList({ items, render, empty, icon, haystack, statusOf }) {
  const [q, setQ] = useState(""), [st, setSt] = useState("all");
  const stOf = statusOf || ((x) => Number(x.status) || 0);
  const needle = q.trim().toLowerCase();
  const list = items.filter((x) => (st === "all" || stOf(x) === Number(st)) && (!needle || haystack(x).toLowerCase().includes(needle)));
  const chips = [["all", "All", items.length]].concat(STAGES.map((s, k) => [String(k), s, items.filter((x) => stOf(x) === k).length]));
  return (
    <div>
      <div className="adm-filter">
        <input className="inp" type="search" placeholder="Search name, mobile, ID or place" aria-label="Search" value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="adm-chips">{chips.map(([v, l, n]) => <button type="button" key={v} className={"adm-chip" + (st === v ? " on" : "")} aria-pressed={st === v} onClick={() => setSt(v)}>{l}<em>{n}</em></button>)}</div>
        <small className="adm-count">Showing {list.length} of {items.length}</small>
      </div>
      {list.length ? list.map((x, i) => render(x, Math.min(i, 8))) : <AdmEmpty icon={icon} text={items.length ? "Nothing matches this search or filter." : empty} />}
    </div>
  );
}

export function AdminPage({ db, setDb, toast }) {
  const [tab, setTab] = useState("ov");
  const [m, setM] = useState(""), [pw, setPw] = useState(""), [otp, setOtp] = useState(""), [err, setErr] = useState("");
  const [bk, setBk] = useState("");
  const [em, setEm] = useState(""), [abusy, setAbusy] = useState(false);
  const loaded = useRef(false);
  const isAdmin = !!(db.session && db.session.role === "admin");
  const commit = (fn) => {
    const d = getDb(); fn(d); const saved = saveDb(d).ok; if (!saved) toast(T.storageFull[0]); setDb({ ...d });
    if (REMOTE && loaded.current) debounced("pub", () => { pushPublicChanges().then((e) => { if (e) toast("Saved here, but the server update failed. Change something again to retry."); }); }, 500);
    return saved;
  };
  useEffect(() => {
    if (!REMOTE || !isAdmin) return undefined;
    let dead = false;
    loadAdminData().then((d) => { if (!dead) { loaded.current = true; setDb({ ...d }); } }).catch(() => { if (!dead) toast("Could not load the latest data from the server."); });
    return () => { dead = true; };
  }, [isAdmin]);
  if (!isAdmin) {
    const login = (e) => {
      e.preventDefault();
      if (REMOTE) {
        setAbusy(true); setErr("");
        sbAdminLogin(em.trim(), pw).then((u) => { setAbusy(false); commit((d) => { d.session = { role: "admin", email: (u && u.email) || em.trim(), at: Date.now() }; }); }).catch((er) => { setAbusy(false); setErr(er && er.message === "not_admin" ? "This account is not an admin." : "Wrong email or password."); });
        return;
      }
      if (m !== ADMIN.mobile || pw !== ADMIN.password || otp !== ADMIN.otp) { setErr("Wrong mobile, password or OTP."); return; }
      commit((d) => { d.session = { role: "admin", mobile: m, at: Date.now() }; });
    };
    return (
      <div className="wrap adm" style={{ maxWidth: 420, paddingBottom: 48 }}>
        <PageHead pill="Admin" plain="Admin " hl="login." />
        {REMOTE ? (
          <form className="card adm-logincard" onSubmit={login} noValidate><div className="adm-lhead"><span className="tile adm-tile"><Icon name="lock" size={24} /></span><div><b>Admin sign in</b><small>Only for authorised staff</small></div></div>
            <Field id="a-email" label="Admin email"><input id="a-email" className="inp" dir="ltr" type="email" autoComplete="username" value={em} onChange={(e) => setEm(e.target.value)} /></Field>
            <Field id="a-pw" label="Password"><input id="a-pw" className="inp" dir="ltr" type="password" autoComplete="current-password" value={pw} onChange={(e) => setPw(e.target.value)} /></Field>
            <Err m={err} /><button type="submit" disabled={abusy} className="btn btn-primary" style={{ width: "100%", marginTop: 14 }}>{abusy ? "Signing in…" : "Login"}</button>
          </form>
        ) : (<div><div className="card" style={{ background: "#fff8e6", marginBottom: 12, padding: 14 }}><b>Demo security – replace with server auth before going live.</b></div>
        <form className="card adm-logincard" onSubmit={login} noValidate><div className="adm-lhead"><span className="tile adm-tile"><Icon name="lock" size={24} /></span><div><b>Admin sign in</b><small>Only for authorised staff</small></div></div>
          <Field id="a-mobile" label="Mobile"><input id="a-mobile" className="inp" dir="ltr" inputMode="numeric" value={m} onChange={(e) => setM(cleanMobile(e.target.value))} /></Field>
          <Field id="a-pw" label="Password"><input id="a-pw" className="inp" dir="ltr" type="password" value={pw} onChange={(e) => setPw(e.target.value)} /></Field>
          <Field id="a-otp" label="OTP"><input id="a-otp" className="inp" dir="ltr" inputMode="numeric" maxLength={6} value={otp} onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))} /></Field>
          <Err m={err} /><button type="submit" className="btn btn-primary" style={{ width: "100%", marginTop: 14 }}>Login</button>
        </form></div>)}
      </div>
    );
  }
  const reqs = db.requests || [], mts = db.meetings || [], enqs = db.enquiries || [];
  const dupKey = (r) => r.mobile + r.category + r.block;
  const dupCount = {}; reqs.forEach((r) => { dupCount[dupKey(r)] = (dupCount[dupKey(r)] || 0) + 1; });
  const setReq = (id, patch) => {
    commit((d) => { d.requests = d.requests.map((r) => (r.id === id ? { ...r, ...patch } : r)); });
    if (REMOTE) debounced("rq:" + id, () => { const r = (getDb().requests || []).find((x) => x.id === id); if (r) adminPatch("requests", id, { status: Number(r.status) || 0, commission: r.commission === "" || r.commission == null || isNaN(Number(r.commission)) ? null : Number(r.commission), follow_up: r.followUp || null, admin_notes: r.adminNotes || "" }).catch(() => toast("Could not update the server.")); });
  };
  const setMt = (id, patch) => {
    commit((d) => { d.meetings = d.meetings.map((r) => (r.id === id ? { ...r, ...patch } : r)); });
    if (REMOTE) debounced("mt:" + id, () => { const r = (getDb().meetings || []).find((x) => x.id === id); if (r) adminPatch("meetings", id, { status: Number(r.status) || 0 }).catch(() => toast("Could not update the server.")); });
  };
  const setEn = (id, patch) => {
    commit((d) => { d.enquiries = (d.enquiries || []).map((r) => (r.id === id ? { ...r, ...patch } : r)); });
    if (REMOTE) debounced("en:" + id, () => { const r = (getDb().enquiries || []).find((x) => x.id === id); if (r) adminPatch("enquiries", id, { status: Number(r.status) || 0 }).catch(() => toast("Could not update the server.")); });
  };
  const exportJson = () => { const d = { ...getDb() }; delete d.session; const txt = JSON.stringify(d, null, 2); setBk(txt); try { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([txt], { type: "application/json" })); a.download = "earthix-backup.json"; a.click(); } catch (e) { /* copy from the box instead */ } };
  const exportCsv = () => { const txt = toCsv(reqs); setBk(txt || "No requests yet."); try { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([txt], { type: "text/csv" })); a.download = "requests.csv"; a.click(); } catch (e) { /* copy from the box instead */ } };
  const importJson = () => { try { const nd = importBackup(bk); if (!saveDb(nd).ok) { toast(T.storageFull[0]); return; } setDb({ ...nd }); toast("Backup imported. Please login again."); } catch (e) { toast("Invalid backup file."); } };
  const logout = () => { sbLogout(); commit((d) => { d.session = null; }); };
  const todayYmd = ymdLocal(new Date());
  const newReqs = reqs.filter((r) => !r.status).length, newEnqs = enqs.filter((r) => !r.status).length;
  const dueFollow = reqs.filter((r) => r.followUp && r.followUp <= todayYmd && (Number(r.status) || 0) < 5).length;
  const dupGroups = Object.keys(dupCount).filter((k) => dupCount[k] > 1).length;
  const propsAll = db.properties || SEED_PROPERTIES;
  const stageN = STAGES.map((s, k) => reqs.filter((r) => (Number(r.status) || 0) === k).length);
  const maxStage = Math.max(1, ...stageN);
  const buyN = reqs.filter((r) => r.type === "buy").length, sellN = reqs.length - buyN;
  const recent = [].concat(
    reqs.map((r) => ({ k: "Request", ic: "users", tab: "rq", id: r.id, name: r.name, mobile: r.mobile, at: r.at || 0 })),
    enqs.map((r) => ({ k: "Enquiry", ic: "mail", tab: "en", id: r.id, name: r.name, mobile: r.mobile, at: r.at || 0 })),
    mts.map((r) => ({ k: "Meeting", ic: "calendar", tab: "mt", id: r.id, name: r.name, mobile: r.mobile, at: r.at || 0 }))
  ).sort((a, b) => b.at - a.at).slice(0, 6);
  const badge = { rq: newReqs, en: newEnqs };
  const tabs = [["ov", "Overview"], ["rq", "Requests"], ["en", "Enquiries"], ["mt", "Meetings"], ["pr", "Properties"], ["rv", "Reviews"], ["br", "Brand & Logo"], ["fd", "Founder"], ["ct", "Content"], ["lc", "Locations"], ["ms", "Messages"], ["st", "Settings"], ["bk", "Backup"]];
  const loc = (r) => [r.village, r.panchayat, r.block, r.district].filter(Boolean).join(", ") || r.block;
  const hello = (r, what) => "Hello " + r.name + ", this is " + BRAND[0] + " about your " + what + ".";
  return (
    <div className="wrap adm" style={{ paddingBottom: 48 }}>
      <div className="adm-hero">
        <div className="adm-htop">
          <span className="tile adm-tile"><Icon name="shield" size={24} /></span>
          <div className="adm-htx">
            <span className="adm-badge"><Icon name="sparkle" size={12} />Admin panel</span>
            <h2>Welcome back, Admin</h2>
            <p>{new Date().toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}</p>
          </div>
          <button type="button" className="btn btn-outline adm-out" onClick={logout}>Logout</button>
        </div>
        <div className="adm-att-row">{[["New requests", newReqs, "rq"], ["New enquiries", newEnqs, "en"], ["Follow-ups due", dueFollow, "rq"], ["Duplicates", dupGroups, "rq"]].map(([l, n, t], k) => <button type="button" key={l} className={"adm-att" + (n ? " on" : "")} style={{ "--n": k }} onClick={() => setTab(t)}><b>{n}</b>{l}</button>)}</div>
      </div>
      <div className="adm-tabs" role="tablist" aria-label="Admin sections">{tabs.map(([k, l]) => <button key={k} type="button" role="tab" className="adm-tab" aria-pressed={tab === k} aria-selected={tab === k} onClick={() => setTab(k)}><Icon name={ADM_TAB_ICON[k]} size={16} />{l}{badge[k] ? <em>{badge[k]}</em> : null}</button>)}</div>
      <div className="adm-body" key={tab}>
      {tab === "ov" && <div>
        <div className="adm-kpis">{[["Requests", reqs.length, "users", "rq"], ["Enquiries", enqs.length, "mail", "en"], ["Meetings", mts.length, "calendar", "mt"], ["Properties", propsAll.length, "home", "pr"], ["Messages", (db.messages || []).length, "phone", "ms"], ["Subscribers", (db.subscribers || []).length, "heart", "ms"]].map(([l, n, ic, t], k) => <button type="button" key={l} className="adm-kpi" style={{ "--n": k }} onClick={() => setTab(t)}><span className="tile adm-tile sm"><Icon name={ic} size={18} /></span><b><AdminCountUp to={n} /></b><span className="l">{l}</span></button>)}</div>
        <div className="adm-panel">
          <h3>Request pipeline</h3>
          {reqs.length ? STAGES.map((s, k) => <div className={"adm-bar st" + k} key={s}><span>{s}</span><div className="adm-track"><i style={{ width: Math.max(stageN[k] ? 6 : 0, Math.round((stageN[k] / maxStage) * 100)) + "%", "--n": k }} /></div><b>{stageN[k]}</b></div>) : <p className="adm-note">No requests yet. They will appear here as stages.</p>}
          {reqs.length > 0 && <div><div className="adm-split"><i className="buy" style={{ flex: buyN || 0.001 }} /><i className="sell" style={{ flex: sellN || 0.001 }} /></div><div className="adm-legend"><span><u className="buy" />Buy {buyN}</span><span><u className="sell" />Sell {sellN}</span></div></div>}
        </div>
        <div className="adm-panel">
          <h3>Property listings</h3>
          <div className="adm-facts">{[["Total", propsAll.length], ["Verified", propsAll.filter((p) => p.verified).length], ["Featured", propsAll.filter((p) => p.featured).length], ["Hidden", propsAll.filter((p) => p.visible === false).length]].map(([l, n]) => <span key={l}>{l}<b className="adm-num">{n}</b></span>)}</div>
        </div>
        <div className="adm-panel">
          <h3>Recent activity</h3>
          {recent.length ? <div className="adm-feed">{recent.map((x, k) => <button type="button" key={x.k + x.id} style={{ "--n": k }} onClick={() => setTab(x.tab)}><span className="adm-dot"><Icon name={x.ic} size={16} /></span><span className="adm-ftx"><b>{x.name || x.id}</b><small>{x.k} · <span dir="ltr">{x.id}</span></small></span><small className="adm-when">{fmtAt(x.at)}</small></button>)}</div> : <p className="adm-note">Nothing yet. New requests, enquiries and meetings will show up here.</p>}
        </div>
        <div className="adm-panel">
          <h3>Quick actions</h3>
          <div className="adm-quick">
            <button type="button" className="btn btn-primary" onClick={() => setTab("pr")}>Add property</button>
            <button type="button" className="btn btn-outline" onClick={() => setTab("rq")}>Review requests</button>
            <button type="button" className="btn btn-outline" onClick={() => setTab("br")}>Edit brand</button>
            <button type="button" className="btn btn-outline" onClick={() => setTab("bk")}>Backup data</button>
          </div>
        </div>
      </div>}
      {tab === "rq" && <AdmList items={reqs} icon="users" empty="No requests yet." statusOf={(r) => Number(r.status) || 0} haystack={(r) => [r.id, r.name, r.mobile, r.block, r.village, r.panchayat, catName(r.category, "en")].join(" ")} render={(r, i) => {
        const dup = dupCount[dupKey(r)] > 1, due = r.followUp && r.followUp <= todayYmd && (Number(r.status) || 0) < 5;
        return (
          <div className={"adm-item" + (dup ? " dup" : "")} key={r.id} style={{ "--n": i }}>
            <div className="adm-ihead">
              <span className={"adm-type " + (r.type === "buy" ? "buy" : "sell")}><Icon name={r.type === "buy" ? "shop" : "rupee"} size={14} />{r.type === "buy" ? "Buy" : "Sell"}</span>
              <b dir="ltr" className="adm-id">{r.id}</b>
              {dup && <span className="adm-flag">Duplicate</span>}
              {due && <span className="adm-flag due">Follow-up due</span>}
              <span className={"adm-stage " + stageCls(r.status)}>{STAGES[Number(r.status) || 0]}</span>
            </div>
            <div className="adm-who"><b>{r.name}</b><a dir="ltr" href={L("tel:+91" + r.mobile)}>{r.mobile}</a><small>{fmtAt(r.at)}</small></div>
            <div className="adm-facts">
              <span><Icon name="layers" size={14} />{catName(r.category, "en")}</span>
              <span><Icon name="pin" size={14} />{loc(r)}</span>
              <span>{r.area} {r.unit}</span>
              <span className="pc">{fmtINR(r.price)}</span>
            </div>
            {r.details && Object.keys(r.details).length ? <p className="adm-det">{detailLines(r.category, r.details, r.type === "buy" ? "buy" : "sell", "en").join(" · ")}</p> : null}
            {(safeUrl(r.mapLink) || safeUrl(r.mediaLink)) && <div className="adm-links">{safeUrl(r.mapLink) ? <a href={L(r.mapLink)} target="_blank" rel="noopener noreferrer">📍 Map</a> : null}{safeUrl(r.mediaLink) ? <a href={L(r.mediaLink)} target="_blank" rel="noopener noreferrer">🖼️ Photos/video</a> : null}</div>}
            {Array.isArray(r.photos) && r.photos.length > 0 && <div className="gadm" style={{ marginTop: 8 }}>{r.photos.map((src, k) => <a key={k} className="gi" href={L(src)} download={r.id + "-photo-" + (k + 1)} title="Download photo"><img src={src} alt={"Seller photo " + (k + 1)} loading="lazy" /></a>)}</div>}
            <AdmContact mobile={r.mobile} msg={hello(r, "request " + r.id)} />
            <div className="adm-fields">
              <div className="full"><label className="lbl" htmlFor={"rs-" + r.id}>Status</label><PickBtn noSearch id={"rs-" + r.id} title="Status" value={String(r.status || 0)} onChange={(v) => setReq(r.id, { status: Number(v) })} options={STAGES.map((s, k) => ({ v: String(k), l: s }))} /></div>
              <div><label className="lbl" htmlFor={"rc-" + r.id}>Commission %</label><input id={"rc-" + r.id} className="inp" dir="ltr" inputMode="decimal" value={r.commission == null ? settings0(db).commission : r.commission} onChange={(e) => setReq(r.id, { commission: e.target.value })} /></div>
              <div><label className={"lbl" + (due ? " due" : "")} htmlFor={"rf-" + r.id}>Follow-up date</label><input id={"rf-" + r.id} className="inp" type="date" dir="ltr" value={r.followUp || ""} onChange={(e) => setReq(r.id, { followUp: e.target.value })} /></div>
              <div className="full"><label className="lbl" htmlFor={"rn-" + r.id}>Admin notes</label><input id={"rn-" + r.id} className="inp" value={r.adminNotes || ""} onChange={(e) => setReq(r.id, { adminNotes: e.target.value })} /></div>
            </div>
          </div>
        );
      }} />}
      {tab === "en" && <AdmList items={enqs.slice().sort((a, b) => (b.at || 0) - (a.at || 0))} icon="mail" empty="No enquiries yet." statusOf={(r) => Number(r.status) || 0} haystack={(r) => [r.id, r.name, r.mobile, r.email, r.propertyTitle, r.message].join(" ")} render={(r, i) => (
        <div className={"adm-item" + (!r.status ? " fresh" : "")} key={r.id} style={{ "--n": i }}>
          <div className="adm-ihead">
            <span className="adm-type buy"><Icon name="mail" size={14} />Enquiry</span>
            <b dir="ltr" className="adm-id">{r.id}</b>
            {!r.status && <span className="adm-flag">New</span>}
            <span className={"adm-stage " + stageCls(r.status)}>{STAGES[Number(r.status) || 0]}</span>
          </div>
          <div className="adm-who"><b>{r.name}</b><a dir="ltr" href={L("tel:+91" + r.mobile)}>{r.mobile}</a><small>{fmtAt(r.at)}</small></div>
          <div className="adm-facts">
            {r.email ? <span><Icon name="mail" size={14} /><a href={L("mailto:" + r.email)} dir="ltr">{r.email}</a></span> : null}
            <span><Icon name="home" size={14} />{r.propertyId ? <a href={L("#/property/" + r.propertyId)}>{r.propertyTitle || r.propertyId}</a> : "General request"}</span>
          </div>
          {r.message ? <p className="adm-det">{r.message}</p> : null}
          <AdmContact mobile={r.mobile} msg={hello(r, "request" + (r.propertyTitle ? " for " + r.propertyTitle : ""))} />
          <div className="adm-fields"><div className="full"><label className="lbl" htmlFor={"es-" + r.id}>Status</label><PickBtn noSearch id={"es-" + r.id} title="Status" value={String(r.status || 0)} onChange={(v) => setEn(r.id, { status: Number(v) })} options={STAGES.map((st, k) => ({ v: String(k), l: st }))} /></div></div>
        </div>
      )} />}
      {tab === "mt" && <AdmList items={mts} icon="calendar" empty="No meetings yet." statusOf={(r) => Number(r.status || 2)} haystack={(r) => [r.id, r.name, r.mobile, r.date, r.slot, r.purpose].join(" ")} render={(r, i) => (
        <div className="adm-item" key={r.id} style={{ "--n": i }}>
          <div className="adm-ihead">
            <span className="adm-type buy"><Icon name="calendar" size={14} />Meeting</span>
            <b dir="ltr" className="adm-id">{r.id}</b>
            <span className={"adm-stage " + stageCls(r.status || 2)}>{STAGES[Number(r.status || 2)]}</span>
          </div>
          <div className="adm-who"><b>{r.name}</b><a dir="ltr" href={L("tel:+91" + r.mobile)}>{r.mobile}</a></div>
          <div className="adm-facts">
            <span><Icon name="calendar" size={14} />{r.date}</span>
            <span><Icon name="clock" size={14} />{r.slot}</span>
            {r.purpose ? <span>{r.purpose}</span> : null}
            {r.bringLater ? <span>Bring docs later</span> : null}
          </div>
          <AdmContact mobile={r.mobile} msg={hello(r, "meeting on " + r.date + " at " + r.slot)} />
          <div className="adm-fields"><div className="full"><label className="lbl" htmlFor={"ms-" + r.id}>Status</label><PickBtn noSearch id={"ms-" + r.id} title="Status" value={String(r.status || 2)} onChange={(v) => setMt(r.id, { status: Number(v) })} options={STAGES.map((s, k) => ({ v: String(k), l: s }))} /></div></div>
        </div>
      )} />}
      {tab === "ms" && <div>
        {(db.messages || []).map((x, k) => <div className="adm-item" key={k} style={{ "--n": Math.min(k, 8) }}><div className="adm-ihead"><span className="adm-type buy"><Icon name="phone" size={14} />Message</span></div><div className="adm-who"><b>{x.name}</b><a dir="ltr" href={L("tel:+91" + x.mobile)}>{x.mobile}</a></div><p className="adm-det">{x.message}</p><AdmContact mobile={x.mobile} msg={hello(x, "message")} /></div>)}
        {(db.subscribers || []).length > 0 && <div className="adm-panel"><h3>Subscribers</h3><div className="adm-facts">{(db.subscribers || []).map((x, k) => <span key={"s" + k} dir="ltr"><Icon name="mail" size={14} />{x.email}</span>)}</div></div>}
        {!(db.messages || []).length && !(db.subscribers || []).length && <AdmEmpty icon="phone" text="Nothing yet." />}
      </div>}
      {tab === "pr" && <AdminProps db={db} commit={commit} toast={toast} />}
      {tab === "rv" && <AdminReviews db={db} commit={commit} toast={toast} />}
      {tab === "lc" && <AdminLocations db={db} commit={commit} toast={toast} />}
      {tab === "br" && <AdminBrand settings={db.settings} onSave={(x, msg) => { if (!x) { toast(msg); return; } commit((d) => { d.settings = { ...d.settings, ...x }; }); toast("Brand saved"); }} />}
      {tab === "fd" && <AdminFounder settings={db.settings} onSave={(x, msg) => { if (!x) { toast(msg); return; } commit((d) => { d.settings = { ...d.settings, ...x }; }); toast("Founder saved"); }} />}
      {tab === "ct" && <AdminContent settings={db.settings} onSave={(x, msg) => { if (!x) { toast(msg); return; } if (commit((d) => { d.settings = { ...d.settings, ...x }; })) toast("Content saved"); }} />}
      {tab === "st" && <SettingsForm settings={db.settings} onSave={(s, msg) => { if (!s) { toast(msg); return; } commit((d) => { d.settings = { ...d.settings, ...s }; }); toast("Settings saved"); }} />}
      {tab === "bk" && <div className="card"><div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><button type="button" className="btn btn-outline" onClick={exportJson}>Export JSON</button><button type="button" className="btn btn-outline" onClick={exportCsv}>Export CSV</button><button type="button" className="btn btn-primary" onClick={importJson}>Import JSON</button></div><label className="lbl" htmlFor="bk-box">Backup data (paste here to import)</label><textarea id="bk-box" className="inp" dir="ltr" style={{ height: 200, padding: 12 }} value={bk} onChange={(e) => setBk(e.target.value)} /></div>}
      </div>
    </div>
  );
}
