"use client";

import React, { useState, useEffect, useLayoutEffect, useRef, useCallback, useMemo, useContext, createContext, startTransition, useId } from "react";
import { hasExactMap, propVideos, realImages, safeUrl } from "@/lib/media";
import { compressImage, compressImage2 } from "@/lib/admin-lib";
import { Field } from "@/components/common";
import { PROP_DESC, SEED_PROPERTIES } from "@/lib/seed";
import { blankProp } from "@/lib/store";
import { PickBtn } from "@/components/forms";
import { BLOCKS_FILTER, CATEGORIES, catName } from "@/lib/config";
import { UNITS, fmtINR } from "@/lib/helpers";


// Admin: manage many photos, video links and the map pin of one property
export function MediaAdmin({ f, setF, toast, newImg, setNewImg, newVid, setNewVid, err }) {
  const addImg = () => { const u = newImg.trim(); if (!(safeUrl(u) || /^data:image\//.test(u))) { toast("Paste a full image link starting with https://"); return; } setF((s) => ({ ...s, gallery: s.gallery.concat(u).slice(0, 12) })); setNewImg(""); };
  const addVid = () => { const u = newVid.trim(); if (!safeUrl(u)) { toast("Paste a full video link starting with https://"); return; } setF((s) => ({ ...s, videos: s.videos.concat(u).slice(0, 6) })); setNewVid(""); };
  const many = async (e) => {
    const files = Array.from(e.target.files || []).slice(0, 10); e.target.value = "";
    if (!files.length) return;
    const out = [];
    for (const file of files) { try { out.push(await compressImage(file)); } catch (x) { /* skip unreadable file */ } }
    if (!out.length) { toast("Could not read these images. Use image links instead."); return; }
    setF((s) => ({ ...s, gallery: s.gallery.concat(out).slice(0, 12) }));
  };
  const set = (k) => (e) => setF((s) => ({ ...s, [k]: e.target.value }));
  return (
    <div className="mediaadm">
      <h4>More photos ({f.gallery.length}/12)</h4>
      {f.gallery.length > 0 && <div className="gadm">{f.gallery.map((src, k) => <div key={k} className="gi"><img src={src} alt={"Photo " + (k + 2)} loading="lazy" /><button type="button" aria-label="Remove photo" onClick={() => setF((s) => ({ ...s, gallery: s.gallery.filter((_, j) => j !== k) }))}>×</button></div>)}</div>}
      <div className="addrow"><input className="inp" dir="ltr" placeholder="Image link https://..." aria-label="Image link" value={newImg} onChange={(e) => setNewImg(e.target.value)} /><button type="button" className="btn btn-outline" onClick={addImg}>Add</button></div>
      <Field id="ap-files" label="Upload several photos (each compressed to 800px)"><input id="ap-files" type="file" accept="image/*" multiple onChange={many} /></Field>
      <h4>Video clips ({f.videos.length}/6)</h4>
      {f.videos.map((v, k) => <div key={v} className="vrow"><span dir="ltr">{v}</span><button type="button" aria-label="Remove video" onClick={() => setF((s) => ({ ...s, videos: s.videos.filter((_, j) => j !== k) }))}>×</button></div>)}
      <div className="addrow"><input className="inp" dir="ltr" placeholder="YouTube link or .mp4 link" aria-label="Video link" value={newVid} onChange={(e) => setNewVid(e.target.value)} /><button type="button" className="btn btn-outline" onClick={addVid}>Add</button></div>
      <p className="hint">Videos play from a link (YouTube or a direct .mp4). Large video files cannot be stored in this browser.</p>
      <h4>Exact place on the map</h4>
      <Field id="ap-mapUrl" label="Google Maps link (open the place in Maps, tap Share, paste the link)" error={err.mapUrl}><input id="ap-mapUrl" className="inp" dir="ltr" placeholder="https://maps.app.goo.gl/..." value={f.mapUrl} onChange={set("mapUrl")} /></Field>
      <div style={{ display: "flex", gap: 10 }}><Field id="ap-lat" label="Latitude (optional)" error={err.lat}><input id="ap-lat" className="inp" dir="ltr" inputMode="decimal" placeholder="25.8800" value={f.lat} onChange={set("lat")} /></Field><Field id="ap-lng" label="Longitude (optional)" error={err.lng}><input id="ap-lng" className="inp" dir="ltr" inputMode="decimal" placeholder="86.6000" value={f.lng} onChange={set("lng")} /></Field></div>
    </div>
  );
}

export function AdminProps({ db, commit, toast }) {
  const list = db.properties || SEED_PROPERTIES;
  const [f, setF] = useState(blankProp), [err, setErr] = useState({});
  const [newImg, setNewImg] = useState(""), [newVid, setNewVid] = useState("");
  const set = (k) => (e) => setF((s) => ({ ...s, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value }));
  const edit = (p) => { setF({ id: p.id, category: p.category, block: p.block, locality: p.locality, area: p.area == null ? "" : String(p.area), unit: p.unit || "Katha", price: String(p.price), verified: !!p.verified, featured: !!p.featured, listingType: p.listingType || "sale", title: p.title[0], titleHi: p.title[1] || "", titleUr: p.title[2] || "", desc: (p.desc || PROP_DESC[p.id] || [""])[0], image: p.image || "", gallery: (p.gallery || []).slice(), videos: [].concat(p.videos || [], p.video || []).filter((v, i, arr) => v && arr.indexOf(v) === i), mapUrl: p.mapUrl || "", lat: p.lat == null ? "" : String(p.lat), lng: p.lng == null ? "" : String(p.lng) }); window.scrollTo(0, 0); };
  const upload = async (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    try { const url = await compressImage(file); setF((s) => ({ ...s, image: url })); } catch (x) { toast("Could not read this image. Use an image URL instead."); }
  };
  const save = (e) => {
    e.preventDefault();
    const er = {};
    if (f.title.trim().length < 3) er.title = "Enter a title.";
    if (!f.locality.trim()) er.locality = "Enter a locality.";
    if (!(Number(f.price) > 0)) er.price = "Enter the price in rupees.";
    if (f.mapUrl.trim() && !safeUrl(f.mapUrl)) er.mapUrl = "Paste the full link starting with https://";
    const hasLa = f.lat.trim() !== "", hasLn = f.lng.trim() !== "";
    if (hasLa !== hasLn) er.lat = "Enter both latitude and longitude.";
    else if (hasLa && (!(Math.abs(Number(f.lat)) <= 90) || !(Math.abs(Number(f.lng)) <= 180))) er.lat = "Latitude must be -90 to 90 and longitude -180 to 180.";
    setErr(er); if (Object.keys(er).length) return;
    const p = { id: f.id || "p" + Date.now().toString(36), category: f.category, block: f.block, locality: f.locality.trim(), area: f.area === "" ? null : Number(f.area), unit: f.unit, price: Number(f.price), verified: f.verified, featured: !!f.featured, listingType: f.listingType, label: "Showcase property", title: [f.title.trim(), f.titleHi.trim() || f.title.trim(), f.titleUr.trim() || f.title.trim()], image: f.image, gallery: f.gallery.slice(0, 12), videos: f.videos.slice(0, 6), video: "", mapUrl: f.mapUrl.trim(), lat: f.lat.trim() === "" ? null : Number(f.lat), lng: f.lng.trim() === "" ? null : Number(f.lng) };
    if (f.desc.trim()) p.desc = [f.desc.trim(), f.desc.trim(), f.desc.trim()];
    commit((d) => { const cur = d.properties || SEED_PROPERTIES.map((x) => ({ ...x })); d.properties = f.id ? cur.map((x) => (x.id === f.id ? { ...x, ...p, visible: x.visible !== false } : x)) : cur.concat({ ...p, visible: true }); });
    toast("Property saved"); setF(blankProp);
  };
  const toggle = (id) => commit((d) => { d.properties = (d.properties || SEED_PROPERTIES.map((x) => ({ ...x }))).map((x) => (x.id === id ? { ...x, visible: x.visible === false } : x)); });
  const feat = (id) => commit((d) => { d.properties = (d.properties || SEED_PROPERTIES.map((x) => ({ ...x }))).map((x) => (x.id === id ? { ...x, featured: !x.featured } : x)); });
  const del = (id) => { if (!window.confirm("Delete this property?")) return; commit((d) => { d.properties = (d.properties || SEED_PROPERTIES.map((x) => ({ ...x }))).filter((x) => x.id !== id); }); };
  const I = (k, label, extra) => <Field id={"ap-" + k} label={label} error={err[k]}><input id={"ap-" + k} className="inp" value={f[k]} onChange={set(k)} {...(extra || {})} /></Field>;
  return (
    <div>
      <form className="card" onSubmit={save} noValidate style={{ marginBottom: 16 }}>
        <h3 className="ct" style={{ marginTop: 0 }}>{f.id ? "Edit property" : "Add property"}</h3>
        <Field id="ap-category" label="Category"><PickBtn id="ap-category" title="Category" value={f.category} onChange={(v) => set("category")({ target: { value: v } })} options={CATEGORIES.map((c) => ({ v: c.slug, l: c.name[0] }))} /></Field>
        <Field id="ap-block" label="Block"><PickBtn id="ap-block" title="Block" value={f.block} onChange={(v) => set("block")({ target: { value: v } })} options={BLOCKS_FILTER.map((b) => ({ v: b, l: b }))} /></Field>
        {I("locality", "Locality", { placeholder: "e.g. Bairiya" })}{I("title", "Title (English)", { placeholder: "e.g. Road-touch plot on Salkhua main road" })}{I("titleHi", "Title (Hindi, optional)")}{I("titleUr", "Title (Urdu, optional)")}
        <Field id="ap-desc" label="Description (optional)"><textarea id="ap-desc" className="inp" style={{ height: 80, padding: 12 }} value={f.desc} onChange={set("desc")} /></Field>
        {I("area", "Area (number, optional)", { dir: "ltr", inputMode: "decimal" })}
        <Field id="ap-unit" label="Unit"><PickBtn id="ap-unit" noSearch title="Unit" value={f.unit} onChange={(v) => set("unit")({ target: { value: v } })} options={UNITS.concat("rooms").map((u) => ({ v: u, l: u }))} /></Field>
        {I("price", "Price (₹)", { dir: "ltr", inputMode: "numeric", placeholder: "e.g. 2600000" })}
        <Field id="ap-type" label="Listing type"><PickBtn id="ap-type" noSearch title="Listing type" value={f.listingType} onChange={(v) => set("listingType")({ target: { value: v } })} options={[{ v: "sale", l: "Sale" }, { v: "rent", l: "Rent (shows /mo)" }]} /></Field>
        <label className="chk"><input id="ap-verified" type="checkbox" checked={f.verified} onChange={set("verified")} /> Admin-verified</label>
        <label className="chk"><input id="ap-featured" type="checkbox" checked={!!f.featured} onChange={set("featured")} /> Show in the top product strip (home page)</label>
        {I("image", "Image URL (or upload below)", { dir: "ltr", placeholder: "e.g. https://images.unsplash.com/photo-..." })}
        <Field id="ap-file" label="Upload image (compressed to 800px)"><input id="ap-file" type="file" accept="image/*" onChange={upload} /></Field>
        <MediaAdmin f={f} setF={setF} toast={toast} newImg={newImg} setNewImg={setNewImg} newVid={newVid} setNewVid={setNewVid} err={err} />
        <div style={{ display: "flex", gap: 10, marginTop: 14 }}><button type="submit" className="btn btn-primary" style={{ flex: 1 }}>Save property</button>{f.id && <button type="button" className="btn btn-outline" onClick={() => setF(blankProp)}>Cancel</button>}</div>
      </form>
      {list.map((p) => (
        <div className="card" key={p.id} style={{ marginBottom: 12, opacity: p.visible === false ? 0.55 : 1 }}>
          <b>{p.title[0]}</b><p className="cb">{catName(p.category, "en")} · {p.block} · {fmtINR(p.price)}{p.verified ? " · Verified" : ""}{p.visible === false ? " · Hidden" : ""}{realImages(p).length > 1 ? " · " + realImages(p).length + " photos" : ""}{propVideos(p).length ? " · " + propVideos(p).length + " video" : ""}{hasExactMap(p) ? " · map pin" : ""}</p>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><button type="button" className="btn btn-outline" style={{ height: 40 }} onClick={() => edit(p)}>Edit</button><button type="button" className="btn btn-outline" style={{ height: 40 }} onClick={() => toggle(p.id)}>{p.visible === false ? "Show" : "Hide"}</button><button type="button" className="btn btn-outline" style={{ height: 40, ...(p.featured ? { background: "#FFF1E0", borderColor: "#E8741A", color: "#C2490A" } : {}) }} onClick={() => feat(p.id)}>{p.featured ? "★ In top strip" : "☆ Add to top strip"}</button><button type="button" className="btn btn-outline" style={{ height: 40, color: "var(--error)", borderColor: "var(--error)" }} onClick={() => del(p.id)}>Delete</button></div>
        </div>
      ))}
    </div>
  );
}

export function ImgPick({ id, label, hint, value, onChange, max, mime, round }) {
  const [busy, setBusy] = useState(false), [msg, setMsg] = useState("");
  const pickFile = (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = "";
    if (!file) return;
    setBusy(true); setMsg("");
    compressImage2(file, max, mime).then((u) => { onChange(u); setBusy(false); }).catch(() => { setBusy(false); setMsg("Could not read this image. Try a JPG or PNG."); });
  };
  const isData = value && value.indexOf("data:") === 0;
  return (
    <div className="fld">
      <div className="lbl">{label}</div>
      {hint ? <div className="hint">{hint}</div> : null}
      {value ? <div className={"imgpv" + (round ? " round" : "")}><img src={value} alt="" /></div> : null}
      <input id={id} className="inp" dir="ltr" placeholder="https://… image link (or upload below)" value={isData ? "" : value} onChange={(e) => onChange(e.target.value.trim())} />
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 8 }}>
        <label className="btn btn-outline" style={{ height: 44, cursor: "pointer" }}>{busy ? "Please wait…" : "Upload from phone / computer"}<input type="file" accept="image/*" hidden onChange={pickFile} /></label>
        {value ? <button type="button" className="btn btn-outline" style={{ height: 44 }} onClick={() => onChange("")}>Remove</button> : null}
      </div>
      {msg ? <div className="err" role="alert">{msg}</div> : null}
    </div>
  );
}
