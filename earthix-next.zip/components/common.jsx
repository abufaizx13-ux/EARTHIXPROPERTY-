"use client";

import React, { useState, useEffect, useLayoutEffect, useRef, useCallback, useMemo, useContext, createContext, startTransition, useId } from "react";
import { H, tr } from "@/lib/i18n";
import { useLang } from "@/lib/lang";
import { BRAND, BRAND_TAG, IMG, LANG_IDX, brandSwap } from "@/lib/brand";
import { CATEGORIES } from "@/lib/config";
import { resizeUrl, sceneDataUrl, sceneKey, sceneUrl } from "@/lib/media";
import { COOKIE_SECONDS } from "@/lib/content";
import { NAV, goBack, L } from "@/lib/nav";
import { DB_KEY, resetStore } from "@/lib/store";


// Heading renderer: plain part (ink) + highlight part (teal); parts come from H, never split by code.
export function Heading({ id, level = 2 }) {
  const { lang } = useLang();
  const [plain0, hi0] = H[id][LANG_IDX[lang] ?? 0];
  const plain = brandSwap(plain0, LANG_IDX[lang] ?? 0), hi = brandSwap(hi0, LANG_IDX[lang] ?? 0);
  const Tag = level === 1 ? "h1" : "h2";
  return (
    <Tag className={level === 1 ? "h1" : "h2"}>
      <span>{plain}</span>
      {hi ? <span className="hl">{hi}</span> : null}
    </Tag>
  );
}


// ---------- ICONS (line icons, stroke 1.75) ----------
export const ICON_PATHS = {
  lock: "M7 11V8a5 5 0 0110 0v3M5 11h14v10H5z",
  rupee: "M7 5h10M7 9h10M7 5c5 0 7 2 7 4s-2 4-7 4l7 7",
  shield: "M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z M9 12l2 2 4-4",
  calendar: "M4 6h16v14H4zM4 10h16M8 3v4M16 3v4",
  home: "M3 11l9-8 9 8M5 10v10h14V10",
  shop: "M3 9l2-5h14l2 5M4 9v11h16V9M9 20v-6h6v6",
  layers: "M12 3l9 5-9 5-9-5zM3 13l9 5 9-5",
  sparkle: "M12 3v6M12 15v6M3 12h6M15 12h6M6 6l3 3M15 15l3 3M18 6l-3 3M9 15l-3 3",
  check: "M5 12l5 5 9-10",
  pin: "M12 21s7-6 7-12a7 7 0 10-14 0c0 6 7 12 7 12zM12 11a2 2 0 100-4 2 2 0 000 4z",
  phone: "M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a2 2 0 01-2 2A16 16 0 013 6a2 2 0 012-2z",
  mail: "M3 6h18v12H3zM3 7l9 7 9-7",
  globe: "M12 3a9 9 0 100 18 9 9 0 000-18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18",
  clock: "M12 3a9 9 0 100 18 9 9 0 000-18zM12 7v5l3 2",
  heart: "M12 20s-8-5-8-11a4.5 4.5 0 018-2.8A4.5 4.5 0 0120 9c0 6-8 11-8 11z",
  users: "M9 11a3 3 0 100-6 3 3 0 000 6zM3 20c0-3 3-5 6-5s6 2 6 5M16 5a3 3 0 010 6M18 15c2 .6 3 2.3 3 5",
  chevL: "M15 5l-7 7 7 7",
  chevR: "M9 5l7 7-7 7",
  arrow: "M5 12h14M13 6l6 6-6 6",
  close: "M6 6l12 12M18 6L6 18",
  menu: "M4 7h16M4 12h16M4 17h16",
};

export function Icon({ name, size = 20, stroke = 1.75, className = "" }) {
  return (
    <svg className={"ic " + className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
      <path d={ICON_PATHS[name] || ICON_PATHS.sparkle} />
    </svg>
  );
}

export function WhatsAppIcon({ size = 24 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false">
      <path d="M12 2a10 10 0 00-8.6 15.1L2 22l5-1.3A10 10 0 1012 2zm0 18.2a8.2 8.2 0 01-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1112 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8s-.4-.1-.6.1-.7.8-.8 1-.3.2-.5.1a6.700 6.700 0 01-3.300-2.900c-.2-.4.2-.4.700-1.300.1-.1 0-.3 0-.4l-.8-1.800c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 00-.7.3 3 3 0 00-.9 2.200 5.200 5.200 0 001.100 2.800 11.900 11.900 0 004.600 4c1.700.7 2.400.8 3.200.7a2.700 2.700 0 001.800-1.300 2.200 2.200 0 00.2-1.300c-.1-.1-.2-.2-.5-.3z" />
    </svg>
  );
}

export function SceneSvg({ category, label, eager, variant = 0 }) {
  const id = CATEGORIES.some((c) => c.slug === category) ? category : "farmland";
  return <img className="scene" src={sceneUrl(id, variant)} alt={label} width={400} height={300} decoding="async" loading={eager ? "eager" : "lazy"} onError={(e) => { const d = sceneDataUrl(id, variant); if (e.currentTarget.src !== d) e.currentTarget.src = d; }} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />;
}

export function SafeImg({ src, category, alt, width = 800, height = 600, className = "", eager = false }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => { setFailed(false); }, [src]);
  const sv = sceneKey(src);
  if (sv !== null || !src || failed) return <SceneSvg category={category} label={alt} eager={eager} variant={sv === null ? 0 : sv} />;
  return <img className={className} src={resizeUrl(src, width)} alt={alt} width={width} height={height} loading={eager ? "eager" : "lazy"} decoding="async" referrerPolicy="no-referrer" onError={() => setFailed(true)} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />;
}


// ---------- SHARED HOOKS ----------
export const prefersReducedMotion = () => typeof window !== "undefined" && window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

export function useSwipe(onLeft, onRight) {
  const x0 = useRef(null);
  return {
    onTouchStart: (e) => { x0.current = e.touches[0].clientX; },
    onTouchEnd: (e) => {
      if (x0.current === null) return;
      const dx = e.changedTouches[0].clientX - x0.current;
      x0.current = null;
      if (Math.abs(dx) > 40) (dx < 0 ? onLeft : onRight)();
    },
  };
}

export function useFocusTrap(active, ref, onEsc) {
  useEffect(() => {
    if (!active || !ref.current) return undefined;
    const node = ref.current;
    const prev = document.activeElement;
    const sel = 'a[href],button:not([disabled]),input,select,textarea,[tabindex]:not([tabindex="-1"])';
    const first = node.querySelector(sel);
    if (first) first.focus();
    const onKey = (e) => {
      if (e.key === "Escape") { onEsc(); return; }
      if (e.key !== "Tab") return;
      const items = Array.from(node.querySelectorAll(sel));
      if (!items.length) return;
      const a = items[0], z = items[items.length - 1];
      if (e.shiftKey && document.activeElement === a) { e.preventDefault(); z.focus(); }
      else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); }
    };
    document.addEventListener("keydown", onKey);
    return () => { document.removeEventListener("keydown", onKey); if (prev && prev.focus) prev.focus(); };
  }, [active, ref, onEsc]);
}


// ---------- B. CATEGORIES ----------
export function SectionHead({ pill, id, sub }) {
  return (
    <div className="sec-head">
      <span className="pill">{pill}</span>
      <Heading id={id} />
      {sub ? <p className="sub">{sub}</p> : null}
    </div>
  );
}


// ---------- PROPERTY CARD (Showcase + Buy): photo carousel, video clip and bold full details ----------
export function SpecList({ rows }) {
  return <dl className="specs">{rows.map(([k, v], i) => <div key={i}><dt>{k}</dt><dd>{v}</dd></div>)}</dl>;
}

export function CountUp({ to }) {
  const ref = useRef(null);
  const [v, setV] = useState(0);
  useEffect(() => {
    const el = ref.current;
    if (!el) return undefined;
    if (!("IntersectionObserver" in window) || (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches)) { setV(to); return undefined; }
    let raf = 0;
    const io = new IntersectionObserver(([e]) => {
      if (!e.isIntersecting) return;
      io.disconnect();
      const t0 = performance.now();
      const tick = (t) => { const k = Math.min(1, (t - t0) / 1400); setV(Math.round(to * (1 - Math.pow(1 - k, 3)))); if (k < 1) raf = requestAnimationFrame(tick); };
      raf = requestAnimationFrame(tick);
    });
    io.observe(el);
    return () => { io.disconnect(); cancelAnimationFrame(raf); };
  }, [to]);
  return <span ref={ref}>{v}</span>;
}

// ---------- DEAL STRIP: Flipkart-style product row (phone 2 cards, tablet 3, desktop 5 per slide; swipe, arrows, dots, auto-slide) ----------
export function useRevealOnce(th) {
  const ref = useRef(null);
  const [on, setOn] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return undefined;
    if (prefersReducedMotion() || typeof IntersectionObserver === "undefined") { setOn(true); return undefined; }
    const io = new IntersectionObserver((es) => { if (es[0].isIntersecting) { setOn(true); io.disconnect(); } }, { threshold: th || 0.3 });
    io.observe(el);
    return () => io.disconnect();
  }, [th]);
  return [ref, on];
}


export function useCardFx() {
  useEffect(() => {
    if (!window.matchMedia || !window.matchMedia("(hover: hover) and (pointer: fine)").matches || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return undefined;
    const SEL = ".card,.pcard,.ctile,.eco-card,.dstat";
    let cur = null, raf = 0, last = null;
    const reset = (el) => { if (el) { el.style.setProperty("--rx", "0deg"); el.style.setProperty("--ry", "0deg"); } };
    const paint = () => {
      raf = 0;
      if (!cur || !last) return;
      const r = cur.getBoundingClientRect();
      if (!r.width) return;
      const x = (last.clientX - r.left) / r.width, y = (last.clientY - r.top) / r.height;
      const k = cur.tagName === "FORM" || cur.querySelector("input,select,textarea") ? 0 : Math.min(1, 380 / r.width);
      cur.style.setProperty("--ry", ((x - 0.5) * 12 * k).toFixed(2) + "deg");
      cur.style.setProperty("--rx", ((0.5 - y) * 9 * k).toFixed(2) + "deg");
      cur.style.setProperty("--mx", (x * 100).toFixed(1) + "%");
      cur.style.setProperty("--my", (y * 100).toFixed(1) + "%");
    };
    const move = (e) => {
      const c = e.target && e.target.closest ? e.target.closest(SEL) : null;
      if (c !== cur) { reset(cur); cur = c; }
      if (!cur) return;
      last = e;
      if (!raf) raf = requestAnimationFrame(paint);
    };
    const leave = (e) => { if (cur && !(e.relatedTarget && cur.contains(e.relatedTarget))) { reset(cur); cur = null; } };
    document.addEventListener("pointermove", move, { passive: true });
    document.addEventListener("pointerout", leave, { passive: true });
    return () => { document.removeEventListener("pointermove", move); document.removeEventListener("pointerout", leave); if (raf) cancelAnimationFrame(raf); };
  }, []);
}

export const Stars = ({ value, size = 16 }) => (
  <span className="rv-stars" style={{ fontSize: size }} role="img" aria-label={Number(value).toFixed(1) + " / 5"}>
    <span className="rv-sb" aria-hidden="true">★★★★★</span>
    <span className="rv-sf" aria-hidden="true" style={{ width: Math.max(0, Math.min(5, value)) * 20 + "%" }}>★★★★★</span>
  </span>
);


// ---------- PAGES ----------
export function PageHead({ pill, plain, hl, sub }) {
  return <div className="sec-head" style={{ paddingTop: 24 }}><span className="pill">{tr(pill)}</span><h1 className="h1"><span>{tr(plain)}</span><span className="hl">{tr(hl)}</span></h1>{sub && <p className="sub">{tr(sub)}</p>}</div>;
}

export function NotFound() {
  const { t } = useLang();
  return <div className="wrap" style={{ textAlign: "center", padding: "80px 20px" }}><h1 className="h1">404</h1><p className="sub">{t("notFound")}</p><p><a className="btn btn-primary" href={L("#/")}>{t("backHome")}</a></p></div>;
}

export const Err = ({ m }) => (m ? <div className="err" role="alert">{tr(m)}</div> : null);

export const Field = ({ id, label, error, hint: h, children }) => <div className="fld"><label htmlFor={id} className="lbl">{tr(label)}</label>{h ? <div className="hint">{tr(h)}</div> : null}{children}<Err m={error} /></div>;

export function CookieBanner() {
  // Shows at the very bottom on EVERY visit and closes itself after COOKIE_SECONDS (OK also closes it).
  const [show, setShow] = useState(true);
  useEffect(() => {
    const id = setTimeout(() => setShow(false), COOKIE_SECONDS * 1000);
    return () => clearTimeout(id);
  }, []);
  if (!show) return null;
  const ok = () => { try { window.localStorage.setItem("pm_cookie", "1"); } catch (e) { /* memory only */ } setShow(false); window.dispatchEvent(new Event("pm-cookie")); };
  return <div className="cookie" role="region" aria-label={tr("Cookies")}><span>{tr("We store your language and saved items in your browser.")} <a href={L("#/legal?tab=cookies")} style={{ textDecoration: "underline" }}>{tr("Cookies")}</a></span><button type="button" className="btn btn-primary" style={{ height: 40 }} onClick={ok}>{tr("OK")}</button><i className="cookie-bar" style={{ animationDuration: COOKIE_SECONDS + "s" }} aria-hidden="true" /></div>;
}


export function OfflineBanner() {
  const [on, setOn] = useState(() => (typeof navigator === "undefined" ? true : navigator.onLine !== false));
  useEffect(() => { const u = () => setOn(true), d = () => setOn(false); window.addEventListener("online", u); window.addEventListener("offline", d); return () => { window.removeEventListener("online", u); window.removeEventListener("offline", d); }; }, []);
  return on ? null : <div className="offline" role="status">{tr("You are offline. Saved data still works; sending WhatsApp needs internet.")}</div>;
}

export function Section({ alt, id, children }) {
  return <section className={"sec" + (alt ? " alt" : "")} id={id}><div className="wrap">{children}</div></section>;
}

export function BackBar() {
  const { t } = useLang();
  return <div className="wrap" style={{ paddingTop: 8, paddingBottom: 0 }}><button type="button" className="backbar" onClick={goBack}><Icon name="chevL" size={20} />{t("back")}</button></div>;
}

// ---------- PM LOGO, SPLASH, MEETING OPEN HELPER ----------
export function PMLogo({ size = 36, uid = "h" }) {
  if (IMG.logo) return <img className="pmlogo pmlogo-img" src={IMG.logo} alt="" width={size} height={size} style={{ width: size, height: size, objectFit: "contain", borderRadius: 10 }} />;
  const gid = "pmg-" + uid;
  return (
    <svg className="pmlogo" width={size} height={size} viewBox="0 0 80 80" role="img" aria-label="Earthix Property logo" focusable="false">
      <defs><linearGradient id={gid} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#B3440A" /><stop offset="1" stopColor="#E8741A" /></linearGradient></defs>
      <rect className="pm-badge" x="2" y="2" width="76" height="76" rx="20" fill={"url(#" + gid + ")"} />
      <path className="pm-sky" d="M12 71V59h7v7h6V52h8v14h5v-6h9v6h6V56h7v15z" fill="#fff" opacity=".16" />
      <path className="pm-roof" d="M25 15 40 6.500 55 15" fill="none" stroke="#fff" strokeOpacity=".6" strokeWidth="2.500" strokeLinecap="round" strokeLinejoin="round" />
      <path className="pm-m" pathLength="1" d="M54 64H28V22" fill="none" stroke="#fff" strokeWidth="7" strokeLinecap="round" strokeLinejoin="round" />
      <path className="pm-p" pathLength="1" d="M28 22h26M28 43h20" fill="none" stroke="#e9b94f" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function Logo({ uid = "h" }) {
  const { lang } = useLang();
  const i = LANG_IDX[lang] ?? 0;
  const parts = BRAND[0].split(" ");
  return (
    <a className="brand pmbrand" href={L("#/")} aria-label={BRAND[i] + " – " + BRAND_TAG[i]}>
      <PMLogo uid={uid} size={36} />
      <span className="pmcol">
        {i === 0 ? <span className="pmwm"><b>{parts[0].toUpperCase()}</b>{parts.length > 1 && <em>{parts.slice(1).join(" ").toUpperCase()}</em>}</span> : <span className="pmwm pmwm-alt">{BRAND[i]}</span>}
        {BRAND_TAG[i] ? <small className="pmtag">{BRAND_TAG[i]}</small> : null}
      </span>
    </a>
  );
}

export class ErrorBoundary extends React.Component {
  constructor(p) { super(p); this.state = { err: false, msg: "" }; }
  static getDerivedStateFromError(e) { return { err: true, msg: String((e && e.message) || e).slice(0, 200) }; }
  reset() {
    try { window.localStorage.removeItem("pm_cookie"); } catch (e) { /* ignore */ }
    resetStore(); NAV.stack = []; NAV.cur = "";
    this.setState({ err: false, msg: "" });
  }
  render() {
    if (!this.state.err) return this.props.children;
    return (
      <div style={{ padding: "48px 20px", textAlign: "center", fontFamily: "Inter,system-ui,sans-serif" }}>
        <h2 style={{ margin: 0 }}>{tr("Something went wrong")}</h2>
        <p style={{ color: "#8A6F5A", fontSize: 13, wordBreak: "break-word" }}>{this.state.msg}</p>
        <p><button type="button" onClick={() => this.setState({ err: false, msg: "" })} style={{ height: 44, padding: "0 20px", marginRight: 8 }}>{tr("Try again")}</button><button type="button" onClick={() => this.reset()} style={{ height: 44, padding: "0 20px" }}>{tr("Reset saved data")}</button></p>
      </div>
    );
  }
}
