import { json, readJson, sameOrigin } from "@/lib/api";
import { allow, clientIp } from "@/lib/rate-limit";
import { verifyTurnstile } from "@/lib/turnstile";

export const runtime = "nodejs";

// The only database functions a visitor may call through this route. Each one validates its own input
// and rate-limits per mobile number inside Postgres (see supabase/schema.sql).
const ALLOWED = ["subscribe", "book_meeting", "submit_request", "send_message", "send_enquiry", "submit_review"];

export async function POST(request) {
  if (!sameOrigin(request)) return json({ error: "forbidden" }, 403);
  const body = await readJson(request, 400 * 1024); // sell requests may carry up to 4 small photos
  if (!body || typeof body.fn !== "string" || ALLOWED.indexOf(body.fn) === -1) return json({ error: "forbidden_function" }, 400);

  const ip = clientIp(request);
  if (!(await allow("submit:ip:" + ip, 20, 600))) return json({ error: "rate_limit" }, 429);
  if (!(await verifyTurnstile(body.cf, ip))) return json({ error: "captcha_failed" }, 403);

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !anon) return json({ error: "backend_off" }, 503);
  const userToken = request.headers.get("x-sb-token");

  try {
    const res = await fetch(url + "/rest/v1/rpc/" + body.fn, {
      method: "POST",
      headers: { apikey: anon, Authorization: "Bearer " + (userToken || anon), "Content-Type": "application/json" },
      body: JSON.stringify(body.args && typeof body.args === "object" ? body.args : {}),
      cache: "no-store",
    });
    const text = await res.text();
    let data = null;
    try { data = text ? JSON.parse(text) : null; } catch (e) { data = null; }
    if (!res.ok) {
      // PostgREST puts our RAISE EXCEPTION text (rate_limit, slot_full, invalid_mobile ...) in "message".
      const msg = data && typeof data.message === "string" ? data.message : "request_failed";
      return json({ error: msg }, res.status >= 500 ? 502 : 400);
    }
    return json({ ok: true, data });
  } catch (e) {
    return json({ error: "request_failed" }, 502);
  }
}
