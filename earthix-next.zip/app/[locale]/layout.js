import { notFound } from "next/navigation";
import "../globals.css";
import AppProvider from "@/components/AppProvider";
import { fetchPublic } from "@/lib/server-data";
import { applyBrand } from "@/lib/brand";
import { hydratePublic } from "@/lib/store";
import { FONT_CSS } from "@/lib/dom";
import { LOCALES, siteJsonLd } from "@/lib/seo";

export const viewport = { width: "device-width", initialScale: 1, themeColor: "#CF5A0C" };

export function generateStaticParams() {
  return LOCALES.map((locale) => ({ locale }));
}

// Runs before first paint: the page background in the stylesheet depends on <html data-page="...">.
const PAGE_SCRIPT = 'try{var p=location.pathname.split("/");document.documentElement.setAttribute("data-page",p[2]||"home")}catch(e){}';

export default async function RootLayout({ children, params }) {
  const { locale } = params;
  if (LOCALES.indexOf(locale) === -1) notFound();
  const pub = await fetchPublic();
  const d = hydratePublic(pub);
  applyBrand(d.settings);
  const ld = siteJsonLd(locale, d.settings);
  return (
    <html lang={locale} dir={locale === "ur" ? "rtl" : "ltr"} suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link rel="stylesheet" href={"https://fonts.googleapis.com/css2?family=" + FONT_CSS.latin + "&display=swap"} />
        <script dangerouslySetInnerHTML={{ __html: PAGE_SCRIPT }} />
      </head>
      <body>
        {ld.map((x, i) => <script key={i} type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(x) }} />)}
        <AppProvider lang={locale} pub={pub}>{children}</AppProvider>
      </body>
    </html>
  );
}
