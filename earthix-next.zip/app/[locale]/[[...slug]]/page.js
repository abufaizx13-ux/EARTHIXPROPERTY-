import { notFound } from "next/navigation";
import PageRouter from "@/components/PageRouter";
import { fetchPublic } from "@/lib/server-data";
import { SEED_PROPERTIES } from "@/lib/seed";
import { applyBrand } from "@/lib/brand";
import { hydratePublic } from "@/lib/store";
import { catBySlug } from "@/lib/config";
import { buildMetadata, LOCALES } from "@/lib/seo";

// Every page of the site. The page body is rendered by the client component PageRouter (the original app's page
// switch); this server file only validates the URL, sets the SEO metadata, and passes the route down.
const PAGES = ["buy", "property", "buy-request", "sell", "track", "book-meeting", "tools", "admin", "faq", "legal", "about", "how-it-works", "categories", "saved", "contact", "success-stories", "login", "dashboard"];

async function load() {
  const pub = await fetchPublic();
  const d = hydratePublic(pub);
  applyBrand(d.settings);
  const props = (d.properties || SEED_PROPERTIES).filter((p) => p.visible !== false);
  return { props };
}

function isValid(parts, props) {
  if (!parts.length) return true;
  if (PAGES.indexOf(parts[0]) === -1) return false;
  if (parts[0] === "buy") return parts.length === 1 || (parts.length === 2 && !!catBySlug(parts[1]));
  if (parts[0] === "property") return parts.length === 2 && props.some((p) => p.id === parts[1]);
  return parts.length === 1;
}

export async function generateMetadata({ params }) {
  const parts = params.slug || [];
  if (LOCALES.indexOf(params.locale) === -1) return {};
  const { props } = await load();
  return buildMetadata(params.locale, parts, props);
}

export default async function Page({ params, searchParams }) {
  const parts = params.slug || [];
  const { props } = await load();
  if (!isValid(parts, props)) notFound();
  const sp = {};
  Object.keys(searchParams || {}).forEach((k) => { const v = searchParams[k]; sp[k] = Array.isArray(v) ? v[0] : v; });
  const route = { path: "/" + parts.join("/"), parts, params: sp };
  return <PageRouter route={route} />;
}
